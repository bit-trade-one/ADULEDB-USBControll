﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btn_duty_read = New System.Windows.Forms.Button
        Me.btn_duty_allset = New System.Windows.Forms.Button
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.numericUpDown10 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown9 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown8 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown7 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown6 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown5 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown4 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown3 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown2 = New System.Windows.Forms.NumericUpDown
        Me.numericUpDown1 = New System.Windows.Forms.NumericUpDown
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.btn_duty_read2 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.btn_duty_allset2 = New System.Windows.Forms.Button
        Me.Label14 = New System.Windows.Forms.Label
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.TextBox19 = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Button20 = New System.Windows.Forms.Button
        Me.Label16 = New System.Windows.Forms.Label
        Me.Button19 = New System.Windows.Forms.Button
        Me.NumericUpDown11 = New System.Windows.Forms.NumericUpDown
        Me.Button18 = New System.Windows.Forms.Button
        Me.NumericUpDown12 = New System.Windows.Forms.NumericUpDown
        Me.Button17 = New System.Windows.Forms.Button
        Me.NumericUpDown13 = New System.Windows.Forms.NumericUpDown
        Me.Button16 = New System.Windows.Forms.Button
        Me.NumericUpDown14 = New System.Windows.Forms.NumericUpDown
        Me.Button15 = New System.Windows.Forms.Button
        Me.NumericUpDown15 = New System.Windows.Forms.NumericUpDown
        Me.Button14 = New System.Windows.Forms.Button
        Me.NumericUpDown16 = New System.Windows.Forms.NumericUpDown
        Me.Button13 = New System.Windows.Forms.Button
        Me.NumericUpDown17 = New System.Windows.Forms.NumericUpDown
        Me.Button12 = New System.Windows.Forms.Button
        Me.NumericUpDown18 = New System.Windows.Forms.NumericUpDown
        Me.Button11 = New System.Windows.Forms.Button
        Me.NumericUpDown19 = New System.Windows.Forms.NumericUpDown
        Me.NumericUpDown20 = New System.Windows.Forms.NumericUpDown
        Me.GroupBox1.SuspendLayout()
        CType(Me.numericUpDown10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btn_duty_read)
        Me.GroupBox1.Controls.Add(Me.btn_duty_allset)
        Me.GroupBox1.Controls.Add(Me.TextBox10)
        Me.GroupBox1.Controls.Add(Me.TextBox9)
        Me.GroupBox1.Controls.Add(Me.TextBox8)
        Me.GroupBox1.Controls.Add(Me.TextBox7)
        Me.GroupBox1.Controls.Add(Me.TextBox6)
        Me.GroupBox1.Controls.Add(Me.TextBox5)
        Me.GroupBox1.Controls.Add(Me.TextBox4)
        Me.GroupBox1.Controls.Add(Me.TextBox3)
        Me.GroupBox1.Controls.Add(Me.TextBox2)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Button10)
        Me.GroupBox1.Controls.Add(Me.Button9)
        Me.GroupBox1.Controls.Add(Me.Button8)
        Me.GroupBox1.Controls.Add(Me.Button7)
        Me.GroupBox1.Controls.Add(Me.Button6)
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.numericUpDown10)
        Me.GroupBox1.Controls.Add(Me.numericUpDown9)
        Me.GroupBox1.Controls.Add(Me.numericUpDown8)
        Me.GroupBox1.Controls.Add(Me.numericUpDown7)
        Me.GroupBox1.Controls.Add(Me.numericUpDown6)
        Me.GroupBox1.Controls.Add(Me.numericUpDown5)
        Me.GroupBox1.Controls.Add(Me.numericUpDown4)
        Me.GroupBox1.Controls.Add(Me.numericUpDown3)
        Me.GroupBox1.Controls.Add(Me.numericUpDown2)
        Me.GroupBox1.Controls.Add(Me.numericUpDown1)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(10, 10)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(825, 155)
        Me.GroupBox1.TabIndex = 100
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "LED設定（1台接続時 Device ID = 1）"
        '
        'btn_duty_read
        '
        Me.btn_duty_read.Location = New System.Drawing.Point(739, 104)
        Me.btn_duty_read.Name = "btn_duty_read"
        Me.btn_duty_read.Size = New System.Drawing.Size(75, 23)
        Me.btn_duty_read.TabIndex = 191
        Me.btn_duty_read.Text = "read"
        Me.btn_duty_read.UseVisualStyleBackColor = True
        '
        'btn_duty_allset
        '
        Me.btn_duty_allset.Location = New System.Drawing.Point(739, 40)
        Me.btn_duty_allset.Name = "btn_duty_allset"
        Me.btn_duty_allset.Size = New System.Drawing.Size(75, 23)
        Me.btn_duty_allset.TabIndex = 190
        Me.btn_duty_allset.Text = "一括設定"
        Me.btn_duty_allset.UseVisualStyleBackColor = True
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(665, 108)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.ReadOnly = True
        Me.TextBox10.Size = New System.Drawing.Size(60, 19)
        Me.TextBox10.TabIndex = 159
        Me.TextBox10.Tag = "9"
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(600, 108)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = True
        Me.TextBox9.Size = New System.Drawing.Size(60, 19)
        Me.TextBox9.TabIndex = 158
        Me.TextBox9.Tag = "8"
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(535, 108)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ReadOnly = True
        Me.TextBox8.Size = New System.Drawing.Size(60, 19)
        Me.TextBox8.TabIndex = 157
        Me.TextBox8.Tag = "7"
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(470, 108)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(60, 19)
        Me.TextBox7.TabIndex = 156
        Me.TextBox7.Tag = "6"
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(405, 108)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(60, 19)
        Me.TextBox6.TabIndex = 155
        Me.TextBox6.Tag = "5"
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(340, 108)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(60, 19)
        Me.TextBox5.TabIndex = 154
        Me.TextBox5.Tag = "4"
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(275, 108)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(60, 19)
        Me.TextBox4.TabIndex = 153
        Me.TextBox4.Tag = "3"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(210, 108)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(60, 19)
        Me.TextBox3.TabIndex = 152
        Me.TextBox3.Tag = "2"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(145, 108)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(60, 19)
        Me.TextBox2.TabIndex = 151
        Me.TextBox2.Tag = "1"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(80, 108)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(60, 19)
        Me.TextBox1.TabIndex = 150
        Me.TextBox1.Tag = "0"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(15, 111)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(60, 12)
        Me.Label13.TabIndex = 112
        Me.Label13.Text = "現在値"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(665, 70)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(60, 23)
        Me.Button10.TabIndex = 149
        Me.Button10.Tag = "9"
        Me.Button10.Text = "set"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(600, 70)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(60, 23)
        Me.Button9.TabIndex = 148
        Me.Button9.Tag = "8"
        Me.Button9.Text = "set"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(535, 70)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(60, 23)
        Me.Button8.TabIndex = 147
        Me.Button8.Tag = "7"
        Me.Button8.Text = "set"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(470, 70)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(60, 23)
        Me.Button7.TabIndex = 146
        Me.Button7.Tag = "6"
        Me.Button7.Text = "set"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(405, 70)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(60, 23)
        Me.Button6.TabIndex = 145
        Me.Button6.Tag = "5"
        Me.Button6.Text = "set"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(340, 70)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(60, 23)
        Me.Button5.TabIndex = 144
        Me.Button5.Tag = "4"
        Me.Button5.Text = "set"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(275, 70)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(60, 23)
        Me.Button4.TabIndex = 143
        Me.Button4.Tag = "3"
        Me.Button4.Text = "set"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(210, 70)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(60, 23)
        Me.Button3.TabIndex = 142
        Me.Button3.Tag = "2"
        Me.Button3.Text = "set"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(145, 70)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(60, 23)
        Me.Button2.TabIndex = 141
        Me.Button2.Tag = "1"
        Me.Button2.Text = "set"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(80, 70)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(60, 23)
        Me.Button1.TabIndex = 140
        Me.Button1.Tag = "0"
        Me.Button1.Text = "set"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'numericUpDown10
        '
        Me.numericUpDown10.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown10.Location = New System.Drawing.Point(665, 40)
        Me.numericUpDown10.Name = "numericUpDown10"
        Me.numericUpDown10.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown10.TabIndex = 139
        Me.numericUpDown10.Tag = "9"
        Me.numericUpDown10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown9
        '
        Me.numericUpDown9.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown9.Location = New System.Drawing.Point(600, 40)
        Me.numericUpDown9.Name = "numericUpDown9"
        Me.numericUpDown9.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown9.TabIndex = 138
        Me.numericUpDown9.Tag = "8"
        Me.numericUpDown9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown8
        '
        Me.numericUpDown8.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown8.Location = New System.Drawing.Point(535, 40)
        Me.numericUpDown8.Name = "numericUpDown8"
        Me.numericUpDown8.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown8.TabIndex = 137
        Me.numericUpDown8.Tag = "7"
        Me.numericUpDown8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown7
        '
        Me.numericUpDown7.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown7.Location = New System.Drawing.Point(470, 40)
        Me.numericUpDown7.Name = "numericUpDown7"
        Me.numericUpDown7.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown7.TabIndex = 136
        Me.numericUpDown7.Tag = "6"
        Me.numericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown6
        '
        Me.numericUpDown6.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown6.Location = New System.Drawing.Point(405, 40)
        Me.numericUpDown6.Name = "numericUpDown6"
        Me.numericUpDown6.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown6.TabIndex = 135
        Me.numericUpDown6.Tag = "5"
        Me.numericUpDown6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown5
        '
        Me.numericUpDown5.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown5.Location = New System.Drawing.Point(340, 40)
        Me.numericUpDown5.Name = "numericUpDown5"
        Me.numericUpDown5.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown5.TabIndex = 134
        Me.numericUpDown5.Tag = "4"
        Me.numericUpDown5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown4
        '
        Me.numericUpDown4.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown4.Location = New System.Drawing.Point(275, 40)
        Me.numericUpDown4.Name = "numericUpDown4"
        Me.numericUpDown4.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown4.TabIndex = 133
        Me.numericUpDown4.Tag = "3"
        Me.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown3
        '
        Me.numericUpDown3.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown3.Location = New System.Drawing.Point(210, 40)
        Me.numericUpDown3.Name = "numericUpDown3"
        Me.numericUpDown3.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown3.TabIndex = 132
        Me.numericUpDown3.Tag = "2"
        Me.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown2
        '
        Me.numericUpDown2.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown2.Location = New System.Drawing.Point(145, 40)
        Me.numericUpDown2.Name = "numericUpDown2"
        Me.numericUpDown2.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown2.TabIndex = 131
        Me.numericUpDown2.Tag = "1"
        Me.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'numericUpDown1
        '
        Me.numericUpDown1.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.numericUpDown1.Location = New System.Drawing.Point(80, 40)
        Me.numericUpDown1.Name = "numericUpDown1"
        Me.numericUpDown1.Size = New System.Drawing.Size(60, 23)
        Me.numericUpDown1.TabIndex = 130
        Me.numericUpDown1.Tag = "0"
        Me.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(15, 45)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(60, 12)
        Me.Label12.TabIndex = 111
        Me.Label12.Text = "LED Duty"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(665, 25)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(60, 12)
        Me.Label11.TabIndex = 129
        Me.Label11.Text = "10"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(600, 25)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(60, 12)
        Me.Label10.TabIndex = 128
        Me.Label10.Text = "9"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(535, 25)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 12)
        Me.Label9.TabIndex = 127
        Me.Label9.Text = "8"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(470, 25)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 12)
        Me.Label8.TabIndex = 126
        Me.Label8.Text = "7"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(405, 25)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 12)
        Me.Label7.TabIndex = 125
        Me.Label7.Text = "6"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(340, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 12)
        Me.Label6.TabIndex = 124
        Me.Label6.Text = "5"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(275, 25)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 12)
        Me.Label5.TabIndex = 123
        Me.Label5.Text = "4"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(210, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 12)
        Me.Label4.TabIndex = 122
        Me.Label4.Text = "3"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(145, 25)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 12)
        Me.Label3.TabIndex = 121
        Me.Label3.Text = "2"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(80, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 12)
        Me.Label2.TabIndex = 120
        Me.Label2.Text = "1"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(15, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 12)
        Me.Label1.TabIndex = 110
        Me.Label1.Text = "LED ID"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btn_duty_read2)
        Me.GroupBox2.Controls.Add(Me.ComboBox1)
        Me.GroupBox2.Controls.Add(Me.btn_duty_allset2)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.TextBox20)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Controls.Add(Me.TextBox19)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.TextBox18)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.TextBox17)
        Me.GroupBox2.Controls.Add(Me.Label24)
        Me.GroupBox2.Controls.Add(Me.TextBox16)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.TextBox15)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.TextBox14)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.TextBox13)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.TextBox12)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.TextBox11)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Button20)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Button19)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown11)
        Me.GroupBox2.Controls.Add(Me.Button18)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown12)
        Me.GroupBox2.Controls.Add(Me.Button17)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown13)
        Me.GroupBox2.Controls.Add(Me.Button16)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown14)
        Me.GroupBox2.Controls.Add(Me.Button15)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown15)
        Me.GroupBox2.Controls.Add(Me.Button14)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown16)
        Me.GroupBox2.Controls.Add(Me.Button13)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown17)
        Me.GroupBox2.Controls.Add(Me.Button12)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown18)
        Me.GroupBox2.Controls.Add(Me.Button11)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown19)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown20)
        Me.GroupBox2.Location = New System.Drawing.Point(10, 175)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(825, 165)
        Me.GroupBox2.TabIndex = 200
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "LED設定（複数台接続時）"
        '
        'btn_duty_read2
        '
        Me.btn_duty_read2.Location = New System.Drawing.Point(739, 128)
        Me.btn_duty_read2.Name = "btn_duty_read2"
        Me.btn_duty_read2.Size = New System.Drawing.Size(75, 23)
        Me.btn_duty_read2.TabIndex = 236
        Me.btn_duty_read2.Text = "read"
        Me.btn_duty_read2.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(84, 22)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 20)
        Me.ComboBox1.TabIndex = 34
        '
        'btn_duty_allset2
        '
        Me.btn_duty_allset2.Location = New System.Drawing.Point(739, 64)
        Me.btn_duty_allset2.Name = "btn_duty_allset2"
        Me.btn_duty_allset2.Size = New System.Drawing.Size(75, 23)
        Me.btn_duty_allset2.TabIndex = 235
        Me.btn_duty_allset2.Text = "一括設定"
        Me.btn_duty_allset2.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(15, 25)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(86, 17)
        Me.Label14.TabIndex = 33
        Me.Label14.Text = "DEVICE ID"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(665, 132)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.ReadOnly = True
        Me.TextBox20.Size = New System.Drawing.Size(60, 19)
        Me.TextBox20.TabIndex = 234
        Me.TextBox20.Tag = "9"
        Me.TextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(15, 49)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(60, 12)
        Me.Label27.TabIndex = 192
        Me.Label27.Text = "LED ID"
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(600, 132)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.ReadOnly = True
        Me.TextBox19.Size = New System.Drawing.Size(60, 19)
        Me.TextBox19.TabIndex = 233
        Me.TextBox19.Tag = "8"
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(80, 49)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(60, 12)
        Me.Label26.TabIndex = 195
        Me.Label26.Text = "1"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(535, 132)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.ReadOnly = True
        Me.TextBox18.Size = New System.Drawing.Size(60, 19)
        Me.TextBox18.TabIndex = 232
        Me.TextBox18.Tag = "7"
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(145, 49)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(60, 12)
        Me.Label25.TabIndex = 196
        Me.Label25.Text = "2"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(470, 132)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.ReadOnly = True
        Me.TextBox17.Size = New System.Drawing.Size(60, 19)
        Me.TextBox17.TabIndex = 231
        Me.TextBox17.Tag = "6"
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(210, 49)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(60, 12)
        Me.Label24.TabIndex = 197
        Me.Label24.Text = "3"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(405, 132)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.ReadOnly = True
        Me.TextBox16.Size = New System.Drawing.Size(60, 19)
        Me.TextBox16.TabIndex = 230
        Me.TextBox16.Tag = "5"
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(275, 49)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(60, 12)
        Me.Label23.TabIndex = 198
        Me.Label23.Text = "4"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(340, 132)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.ReadOnly = True
        Me.TextBox15.Size = New System.Drawing.Size(60, 19)
        Me.TextBox15.TabIndex = 229
        Me.TextBox15.Tag = "4"
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(340, 49)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(60, 12)
        Me.Label22.TabIndex = 199
        Me.Label22.Text = "5"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(275, 132)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.ReadOnly = True
        Me.TextBox14.Size = New System.Drawing.Size(60, 19)
        Me.TextBox14.TabIndex = 228
        Me.TextBox14.Tag = "3"
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(405, 49)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(60, 12)
        Me.Label21.TabIndex = 200
        Me.Label21.Text = "6"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(210, 132)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.ReadOnly = True
        Me.TextBox13.Size = New System.Drawing.Size(60, 19)
        Me.TextBox13.TabIndex = 227
        Me.TextBox13.Tag = "2"
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(470, 49)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(60, 12)
        Me.Label20.TabIndex = 201
        Me.Label20.Text = "7"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(145, 132)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.ReadOnly = True
        Me.TextBox12.Size = New System.Drawing.Size(60, 19)
        Me.TextBox12.TabIndex = 226
        Me.TextBox12.Tag = "1"
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(535, 49)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(60, 12)
        Me.Label19.TabIndex = 202
        Me.Label19.Text = "8"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(80, 132)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.ReadOnly = True
        Me.TextBox11.Size = New System.Drawing.Size(60, 19)
        Me.TextBox11.TabIndex = 225
        Me.TextBox11.Tag = "0"
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(600, 49)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(60, 12)
        Me.Label18.TabIndex = 203
        Me.Label18.Text = "9"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(15, 135)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(60, 12)
        Me.Label15.TabIndex = 194
        Me.Label15.Text = "現在値"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(665, 49)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 12)
        Me.Label17.TabIndex = 204
        Me.Label17.Text = "10"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(665, 94)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(60, 23)
        Me.Button20.TabIndex = 224
        Me.Button20.Tag = "9"
        Me.Button20.Text = "set"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(15, 69)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(60, 12)
        Me.Label16.TabIndex = 193
        Me.Label16.Text = "LED Duty"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(600, 94)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(60, 23)
        Me.Button19.TabIndex = 223
        Me.Button19.Tag = "8"
        Me.Button19.Text = "set"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'NumericUpDown11
        '
        Me.NumericUpDown11.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown11.Location = New System.Drawing.Point(80, 64)
        Me.NumericUpDown11.Name = "NumericUpDown11"
        Me.NumericUpDown11.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown11.TabIndex = 205
        Me.NumericUpDown11.Tag = "0"
        Me.NumericUpDown11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(535, 94)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(60, 23)
        Me.Button18.TabIndex = 222
        Me.Button18.Tag = "7"
        Me.Button18.Text = "set"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'NumericUpDown12
        '
        Me.NumericUpDown12.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown12.Location = New System.Drawing.Point(145, 64)
        Me.NumericUpDown12.Name = "NumericUpDown12"
        Me.NumericUpDown12.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown12.TabIndex = 206
        Me.NumericUpDown12.Tag = "1"
        Me.NumericUpDown12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(470, 94)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(60, 23)
        Me.Button17.TabIndex = 221
        Me.Button17.Tag = "6"
        Me.Button17.Text = "set"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'NumericUpDown13
        '
        Me.NumericUpDown13.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown13.Location = New System.Drawing.Point(210, 64)
        Me.NumericUpDown13.Name = "NumericUpDown13"
        Me.NumericUpDown13.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown13.TabIndex = 207
        Me.NumericUpDown13.Tag = "2"
        Me.NumericUpDown13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(405, 94)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(60, 23)
        Me.Button16.TabIndex = 220
        Me.Button16.Tag = "5"
        Me.Button16.Text = "set"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'NumericUpDown14
        '
        Me.NumericUpDown14.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown14.Location = New System.Drawing.Point(275, 64)
        Me.NumericUpDown14.Name = "NumericUpDown14"
        Me.NumericUpDown14.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown14.TabIndex = 208
        Me.NumericUpDown14.Tag = "3"
        Me.NumericUpDown14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(340, 94)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(60, 23)
        Me.Button15.TabIndex = 219
        Me.Button15.Tag = "4"
        Me.Button15.Text = "set"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'NumericUpDown15
        '
        Me.NumericUpDown15.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown15.Location = New System.Drawing.Point(340, 64)
        Me.NumericUpDown15.Name = "NumericUpDown15"
        Me.NumericUpDown15.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown15.TabIndex = 209
        Me.NumericUpDown15.Tag = "4"
        Me.NumericUpDown15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(275, 94)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(60, 23)
        Me.Button14.TabIndex = 218
        Me.Button14.Tag = "3"
        Me.Button14.Text = "set"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'NumericUpDown16
        '
        Me.NumericUpDown16.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown16.Location = New System.Drawing.Point(405, 64)
        Me.NumericUpDown16.Name = "NumericUpDown16"
        Me.NumericUpDown16.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown16.TabIndex = 210
        Me.NumericUpDown16.Tag = "5"
        Me.NumericUpDown16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(210, 94)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(60, 23)
        Me.Button13.TabIndex = 217
        Me.Button13.Tag = "2"
        Me.Button13.Text = "set"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'NumericUpDown17
        '
        Me.NumericUpDown17.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown17.Location = New System.Drawing.Point(470, 64)
        Me.NumericUpDown17.Name = "NumericUpDown17"
        Me.NumericUpDown17.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown17.TabIndex = 211
        Me.NumericUpDown17.Tag = "6"
        Me.NumericUpDown17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(145, 94)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(60, 23)
        Me.Button12.TabIndex = 216
        Me.Button12.Tag = "1"
        Me.Button12.Text = "set"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'NumericUpDown18
        '
        Me.NumericUpDown18.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown18.Location = New System.Drawing.Point(535, 64)
        Me.NumericUpDown18.Name = "NumericUpDown18"
        Me.NumericUpDown18.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown18.TabIndex = 212
        Me.NumericUpDown18.Tag = "7"
        Me.NumericUpDown18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(80, 94)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(60, 23)
        Me.Button11.TabIndex = 215
        Me.Button11.Tag = "0"
        Me.Button11.Text = "set"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'NumericUpDown19
        '
        Me.NumericUpDown19.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown19.Location = New System.Drawing.Point(600, 64)
        Me.NumericUpDown19.Name = "NumericUpDown19"
        Me.NumericUpDown19.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown19.TabIndex = 213
        Me.NumericUpDown19.Tag = "8"
        Me.NumericUpDown19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown20
        '
        Me.NumericUpDown20.Font = New System.Drawing.Font("MS UI Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.NumericUpDown20.Location = New System.Drawing.Point(665, 64)
        Me.NumericUpDown20.Name = "NumericUpDown20"
        Me.NumericUpDown20.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown20.TabIndex = 214
        Me.NumericUpDown20.Tag = "9"
        Me.NumericUpDown20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(844, 351)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form1"
        Me.Text = "USB LED Controller ライブラリサンプル"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.numericUpDown10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents numericUpDown10 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown9 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown8 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown7 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown6 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown5 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents numericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents btn_duty_read As System.Windows.Forms.Button
    Friend WithEvents btn_duty_allset As System.Windows.Forms.Button
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btn_duty_read2 As System.Windows.Forms.Button
    Friend WithEvents btn_duty_allset2 As System.Windows.Forms.Button
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown11 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown12 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown13 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown14 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown15 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown16 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown17 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown18 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown19 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown20 As System.Windows.Forms.NumericUpDown

End Class
