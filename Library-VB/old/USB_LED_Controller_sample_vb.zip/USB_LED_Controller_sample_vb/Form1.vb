﻿Imports USB_LED_Controller_Library
Imports Microsoft.Win32.SafeHandles

Public Class Form1

    Private Const LED_NUM As Integer = 10
    Private Const DEVICE_MAX_NUM As Integer = 5
    Private num_LED_duty() As NumericUpDown
    Private txtbx_LED_Duty() As TextBox
    Private num_LED_duty2() As NumericUpDown
    Private txtbx_LED_Duty2() As TextBox

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        num_LED_duty = New NumericUpDown() {numericUpDown1, numericUpDown2, numericUpDown3, numericUpDown4, numericUpDown5, numericUpDown6, numericUpDown7, numericUpDown8, numericUpDown9, numericUpDown10}
        txtbx_LED_Duty = New TextBox() {TextBox1, TextBox2, TextBox3, TextBox4, TextBox5, TextBox6, TextBox7, TextBox8, TextBox9, TextBox10}
        num_LED_duty2 = New NumericUpDown() {NumericUpDown11, NumericUpDown12, NumericUpDown13, NumericUpDown14, NumericUpDown15, NumericUpDown16, NumericUpDown17, NumericUpDown18, NumericUpDown19, NumericUpDown20}
        txtbx_LED_Duty2 = New TextBox() {TextBox11, TextBox12, TextBox13, TextBox14, TextBox15, TextBox16, TextBox17, TextBox18, TextBox19, TextBox20}

        For fi = 1 To DEVICE_MAX_NUM Step 1
            ComboBox1.Items.Add(String.Format("Device ID = {0}", fi))
        Next fi
        ComboBox1.SelectedIndex = 0
    End Sub

    Private Sub btn_duty_allset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_duty_allset.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBLEDController.openUSBLEDController(Me.Handle, 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim set_duty(LED_NUM - 1) As Byte
                For fi = 0 To (LED_NUM - 1) Step 1
                    set_duty(fi) = Byte.Parse(num_LED_duty(fi).Value.ToString())
                Next
                i_ret = USBLEDController.writeLEDAllData(handle_usb_device, 1, set_duty)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, 1)
            End If
        End Try
    End Sub

    Private Sub btn_duty_set_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click, Button8.Click, Button7.Click, Button6.Click, Button5.Click, Button4.Click, Button3.Click, Button2.Click, Button10.Click, Button1.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBLEDController.openUSBLEDController(Me.Handle, 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim button = CType(sender, Button)
                Dim idx As Integer = Integer.Parse(button.Tag.ToString())
                Dim set_duty As Byte
                set_duty = Byte.Parse(num_LED_duty(idx).Value.ToString())
                i_ret = USBLEDController.writeLEDData(handle_usb_device, 1, idx + 1, set_duty)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, 1)
            End If
        End Try
    End Sub

    Private Sub btn_duty_read_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_duty_read.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Try
            'USB DEVICEオープン
            handle_usb_device = USBLEDController.openUSBLEDController(Me.Handle, 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim read_duty(LED_NUM - 1) As Byte
                i_ret = USBLEDController.readLEDData(handle_usb_device, 1, read_duty, LED_NUM)
                For fi = 0 To (LED_NUM - 1) Step 1
                    txtbx_LED_Duty(fi).Text = String.Format("{0}", read_duty(fi))
                Next
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, 1)
            End If
        End Try
    End Sub

    Private Sub btn_duty_allset2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_duty_allset2.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Dim device_idx As Integer = ComboBox1.SelectedIndex
        Try
            'USB DEVICEオープン
            handle_usb_device = USBLEDController.openUSBLEDController(Me.Handle, device_idx + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim set_duty(LED_NUM - 1) As Byte
                For fi = 0 To (LED_NUM - 1) Step 1
                    set_duty(fi) = Byte.Parse(num_LED_duty2(fi).Value.ToString())
                Next
                i_ret = USBLEDController.writeLEDAllData(handle_usb_device, device_idx + 1, set_duty)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, device_idx + 1)
            End If
        End Try
    End Sub

    Private Sub btn_duty_set2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click, Button19.Click, Button18.Click, Button17.Click, Button16.Click, Button15.Click, Button14.Click, Button13.Click, Button12.Click, Button11.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Dim device_idx As Integer = ComboBox1.SelectedIndex
        Try
            'USB DEVICEオープン
            handle_usb_device = USBLEDController.openUSBLEDController(Me.Handle, device_idx + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim button = CType(sender, Button)
                Dim idx As Integer = Integer.Parse(button.Tag.ToString())
                Dim set_duty As Byte
                set_duty = Byte.Parse(num_LED_duty2(idx).Value.ToString())
                i_ret = USBLEDController.writeLEDData(handle_usb_device, device_idx + 1, idx + 1, set_duty)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, device_idx + 1)
            End If
        End Try
    End Sub

    Private Sub btn_duty_read2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_duty_read2.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim i_ret As Integer = 0
        Dim device_idx As Integer = ComboBox1.SelectedIndex
        Try
            'USB DEVICEオープン
            handle_usb_device = USBLEDController.openUSBLEDController(Me.Handle, device_idx + 1)
            If (Not handle_usb_device Is Nothing) Then
                Dim read_duty(LED_NUM - 1) As Byte
                i_ret = USBLEDController.readLEDData(handle_usb_device, device_idx + 1, read_duty, LED_NUM)
                For fi = 0 To (LED_NUM - 1) Step 1
                    txtbx_LED_Duty2(fi).Text = String.Format("{0}", read_duty(fi))
                Next
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEクローズ
                i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, device_idx + 1)
            End If
        End Try
    End Sub
End Class
