//USBRelayControllerLib.h
#include "stdafx.h"

#ifdef __cplusplus
#define EXPORT extern "C" __declspec (dllexport)
#else
#define EXPORT __declspec (dllexport)
#endif

EXPORT HANDLE __stdcall openUSBLEDController(HANDLE hRecipient, int device_id);
EXPORT int __stdcall closeUSBLEDController(HANDLE HandleToUSBDevice, int device_id);
EXPORT int __stdcall writeLEDOutput(HANDLE HandleToUSBDevice, int device_id, int led_no, BYTE set_duty);
EXPORT int __stdcall writeLEDOutputAll(HANDLE HandleToUSBDevice, int device_id, BYTE* set_duty, int set_duty_len);
EXPORT int __stdcall readLEDData(HANDLE HandleToUSBDevice, int device_id, BYTE* led_duty, int read_led_num);


