// USBLEDControllerLib.cpp : DLL �A�v���P�[�V�����p�ɃG�N�X�|�[�g�����֐����`���܂��B
//

#include "stdafx.h"
#include "USBLEDControllerLib.h"
#include <stdexcept>

using namespace std;


BYTE MY_DEVICE_ID[DEVICE_ID_NUM][20] = { "Vid_22EA&Pid_005D", "Vid_22EA&Pid_0062", "Vid_22EA&Pid_0063", "Vid_22EA&Pid_0064", "Vid_22EA&Pid_0065" };
//#define MY_DEVICE_ID2  "Mi_02"

GUID InterfaceClassGuid = {0x4d1e55b2, 0xf16f, 0x11cf, 0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30};
PSP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA;	//Global

BOOL AttachedState[DEVICE_ID_NUM];						//Need to keep track of the USB device attachment status for proper plug and play operation.
HANDLE ReadWriteHandleToUSBDevice[DEVICE_ID_NUM];

#ifdef UNICODE
static wchar_t DevicePath[DEVICE_ID_NUM][256];
#else
static char DevicePath[device_id][256];
#endif


bool CheckIfPresentAndGetUSBDevicePath(int device_id)
{
	HDEVINFO DeviceInfoTable = INVALID_HANDLE_VALUE;
	PSP_DEVICE_INTERFACE_DATA InterfaceDataStructure = new SP_DEVICE_INTERFACE_DATA;
//		PSP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA;	//Globally declared instead
	SP_DEVINFO_DATA DevInfoData;

	DWORD InterfaceIndex = 0;
	DWORD StatusLastError = 0;
	DWORD dwRegType;
	DWORD dwRegSize;
	DWORD StructureSize = 0;
	PBYTE PropertyValueBuffer;
	bool MatchFound = false;
	bool MatchFound2 = false;
	DWORD ErrorStatus;
	BOOL BoolStatus = FALSE;
	DWORD LoopCounter = 0;

	#ifdef UNICODE
	wchar_t tmpDevicePath[256];
	#else
	char tmpDevicePath[256];
	#endif

	#ifdef UNICODE
	wchar_t DeviceIDToFind[256] = {0};
	wchar_t DeviceIDToFind2[256] = {0};
	#else
	char DeviceIDToFind[256] = {0};
	char DeviceIDToFind2[256] = {0};
	#endif

	if(0 <= device_id && device_id < DEVICE_ID_NUM)
	{	// Para OK
	}
	else
	{
		delete InterfaceDataStructure;
		return FALSE;
	}

	//First populate a list of plugged in devices (by specifying "DIGCF_PRESENT"), which are of the specified class GUID. 
	DeviceInfoTable = SetupDiGetClassDevs(&InterfaceClassGuid, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

	tmpDevicePath[0] = 0x00;
    int device_found_count = 0;
    bool device_id_found = false;


	//Now look through the list we just populated.  We are trying to see if any of them match our device. 
	while(true)
	{
		tmpDevicePath[0] = 0x00;
		if (device_found_count > 16)
		{
			break;
		}

		InterfaceDataStructure->cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
		if(SetupDiEnumDeviceInterfaces(DeviceInfoTable, NULL, &InterfaceClassGuid, InterfaceIndex, InterfaceDataStructure))
		{
			ErrorStatus = GetLastError();
			if(ErrorStatus == ERROR_NO_MORE_ITEMS)	//Did we reach the end of the list of matching devices in the DeviceInfoTable?
			{	//Cound not find the device.  Must not have been attached.
				SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				break;
				//return FALSE;
			}
		}
		else	//Else some other kind of unknown error ocurred...
		{
			ErrorStatus = GetLastError();
			SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
			break;
			//return FALSE;
		}

		//Now retrieve the hardware ID from the registry.  The hardware ID contains the VID and PID, which we will then 
		//check to see if it is the correct device or not.

		//Initialize an appropriate SP_DEVINFO_DATA structure.  We need this structure for SetupDiGetDeviceRegistryProperty().
		DevInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
		SetupDiEnumDeviceInfo(DeviceInfoTable, InterfaceIndex, &DevInfoData);

		//First query for the size of the hardware ID, so we can know how big a buffer to allocate for the data.
		SetupDiGetDeviceRegistryProperty(DeviceInfoTable, &DevInfoData, SPDRP_HARDWAREID, &dwRegType, NULL, 0, &dwRegSize);

		//Allocate a buffer for the hardware ID.
		PropertyValueBuffer = (BYTE *) malloc (dwRegSize);
		if(PropertyValueBuffer == NULL)	//if null, error, couldn't allocate enough memory
		{	//Can't really recover from this situation, just exit instead.
			SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
			delete InterfaceDataStructure;
			return FALSE;		
		}

		//Retrieve the hardware IDs for the current device we are looking at.  PropertyValueBuffer gets filled with a 
		//REG_MULTI_SZ (array of null terminated strings).  To find a device, we only care about the very first string in the
		//buffer, which will be the "device ID".  The device ID is a string which contains the VID and PID, in the example 
		//format "Vid_04d8&Pid_003f".
		SetupDiGetDeviceRegistryProperty(DeviceInfoTable, &DevInfoData, SPDRP_HARDWAREID, &dwRegType, PropertyValueBuffer, dwRegSize, NULL);

		#ifdef UNICODE
		wchar_t device_str_c1[256] = {0};
		wchar_t *dev_cp = (wchar_t *)PropertyValueBuffer;
		#else
		char device_str_c1[256] = {0};
		char *dev_cp = (char *)PropertyValueBuffer;
		#endif

		int count = 0;
		// ������R�s�[���R�s�[���ď������ɕϊ�
		while(*dev_cp != 0x00)
		{
			// ������R�s�[
			device_str_c1[count] = *dev_cp;
			// �������ɕϊ�
			device_str_c1[count] = tolower(device_str_c1[count]);

			count++;
			dev_cp++;
			//PropertyValueBuffer += sizeof(wchar_t);
		}

		count = 0;
		while(MY_DEVICE_ID[device_id][count] != 0)
		{
			DeviceIDToFind[count] = MY_DEVICE_ID[device_id][count];
			DeviceIDToFind[count] = tolower(DeviceIDToFind[count]);
			count++;
		}
		//count = 0;
		//while(MY_DEVICE_ID2[count] != 0)
		//{
		//	DeviceIDToFind2[count] = MY_DEVICE_ID2[count];
		//	DeviceIDToFind2[count] = tolower(DeviceIDToFind2[count]);
		//	count++;
		//}

		
		#ifdef UNICODE
		if(wcsstr(device_str_c1, DeviceIDToFind) != NULL)
		{
			MatchFound = true;
		}
		else
		{
			MatchFound = false;
		}
		//if(wcsstr(device_str_c1, DeviceIDToFind2) != NULL)
		//{
		//	MatchFound2 = true;
		//}
		//else
		//{
		//	MatchFound2 = false;
		//}
		#else
		if(strstr(device_str_c1, DeviceIDToFind) != NULL)
		{
			MatchFound = true;
		}
		else
		{
			MatchFound = false;
		}
		//if(strstr(device_str_c1, DeviceIDToFind2) != NULL)
		//{
		//	MatchFound2 = true;
		//}
		//else
		//{
		//	MatchFound2 = false;
		//}
		#endif
		MatchFound2 = true;

		free(PropertyValueBuffer);		//No longer need the PropertyValueBuffer, free the memory to prevent potential memory leaks

		if((MatchFound == true) && (MatchFound2 == true))
		{
			//Device must have been found.  Open WinUSB interface handle now.  In order to do this, we will need the actual device path first.
			//We can get the path by calling SetupDiGetDeviceInterfaceDetail(), however, we have to call this function twice:  The first
			//time to get the size of the required structure/buffer to hold the detailed interface data, then a second time to actually 
			//get the structure (after we have allocated enough memory for the structure.)
			DetailedInterfaceDataStructure->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
			//First call populates "StructureSize" with the correct value
			SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, InterfaceDataStructure, NULL, NULL, &StructureSize, NULL);	
			PSP_DEVICE_INTERFACE_DETAIL_DATA pDetailedInterfaceDataStructure = NULL;
			pDetailedInterfaceDataStructure = (PSP_DEVICE_INTERFACE_DETAIL_DATA)(malloc(StructureSize));		//Allocate enough memory
			//DetailedInterfaceDataStructure = (PSP_DEVICE_INTERFACE_DETAIL_DATA)(malloc(StructureSize));		//Allocate enough memory
			//if(DetailedInterfaceDataStructure == NULL)	//if null, error, couldn't allocate enough memory
			if(pDetailedInterfaceDataStructure == NULL)	//if null, error, couldn't allocate enough memory
			{	//Can't really recover from this situation, just exit instead.
				SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				delete InterfaceDataStructure;
				return FALSE;
			}
			pDetailedInterfaceDataStructure->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
			//DetailedInterfaceDataStructure->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
			 //Now call SetupDiGetDeviceInterfaceDetail() a second time to receive the goods.  
			//if(SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, InterfaceDataStructure, DetailedInterfaceDataStructure, StructureSize, NULL, NULL))
			if(SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, InterfaceDataStructure, pDetailedInterfaceDataStructure, StructureSize, NULL, NULL))
			{
#ifdef UNICODE
				wcscpy(&tmpDevicePath[0], pDetailedInterfaceDataStructure->DevicePath);
#else
				strcpy(&tmpDevicePath[0], pDetailedInterfaceDataStructure->DevicePath);
#endif
				//We now have the proper device path, and we can finally open a device handle to the device.
				//WinUSB requires the device handle to be opened with the FILE_FLAG_OVERLAPPED attribute.
				//SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				free(pDetailedInterfaceDataStructure);
				//return TRUE;

				// USB�ʐM���ăf�o�C�XID���擾����
				HANDLE tmpReadWriteHandleToUSBDevice = INVALID_HANDLE_VALUE;
				DWORD ErrorStatusReadWrite;

				// ���łɃI�[�v���ς݂��m�F����
				bool create_file_opened = FALSE;
				bool comm_error = FALSE;
				bool comm_skip = FALSE;
				for(int fi = 0; fi < DEVICE_ID_NUM; fi++)
				{
#ifdef UNICODE
					if(wcscmp(&tmpDevicePath[0], &DevicePath[fi][0]) == 0)
#else
					if(strcmp(&tmpDevicePath[0], &DevicePath[device_id][0]) == 0)
#endif
					{
						// �����f�o�C�XID�ł��łɃI�[�v���ς�
						// �ڑ������A�Ċm�F�̂��ߒʐM����
						if(device_id == fi)
						{
							tmpReadWriteHandleToUSBDevice = ReadWriteHandleToUSBDevice[device_id];
							ErrorStatusReadWrite = ERROR_SUCCESS;
							create_file_opened = TRUE;
							break;
						}
						else
						{	// �Ⴄ�f�o�C�XID�ł��łɃI�[�v���ς�
							comm_skip = TRUE;	// �X�L�b�v
							break;
						}
					}
				}

				if(comm_skip == FALSE)
				{
					if(tmpReadWriteHandleToUSBDevice == INVALID_HANDLE_VALUE)
					{
						tmpReadWriteHandleToUSBDevice = CreateFile(&tmpDevicePath[0], GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, 0);
						ErrorStatusReadWrite = GetLastError();
					}

					if(ErrorStatusReadWrite == ERROR_SUCCESS)
					{
						BYTE OUTBuffer[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
						BYTE INBuffer[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
						DWORD BytesWritten = 0;
						DWORD BytesRead = 0;
						
						for(int fi = 0; fi < sizeof(OUTBuffer); fi++)
						{
							OUTBuffer[fi] = 0xFF;
						}
						OUTBuffer[0] = 0;
						OUTBuffer[1] = 0x21;
						if (WriteFile(tmpReadWriteHandleToUSBDevice, &OUTBuffer, 65, &BytesWritten, 0))
						{
							INBuffer[0] = 0;
							if (ReadFile(tmpReadWriteHandleToUSBDevice, &INBuffer, 65, &BytesRead, 0))
							{
								if (INBuffer[1] == 0x21)
								{
									device_id_found = true;
								}
							}
							else
							{
								// �ʐM�ُ�
								comm_error = TRUE;
							}
						}
						else
						{
							// �ʐM�ُ�
							comm_error = TRUE;
						}

						if(create_file_opened == FALSE)
						{
							CloseHandle(tmpReadWriteHandleToUSBDevice);
							tmpReadWriteHandleToUSBDevice = INVALID_HANDLE_VALUE;
						}

						// �ʐM�ُ�ŁA���łɃI�[�v���ς݂̏ꍇ�̓N���[�Y����
						if(comm_error == TRUE)
						{
							if(create_file_opened == TRUE)
							{
								CloseHandle(ReadWriteHandleToUSBDevice[device_id]);
								ReadWriteHandleToUSBDevice[device_id] = INVALID_HANDLE_VALUE;
								DevicePath[device_id][0] = 0x00;
							}
						}
						else
						{	// �ʐM����
#ifdef UNICODE
							wcscpy(&DevicePath[device_id][0], &tmpDevicePath[0]);
#else
							strcpy(&DevicePath[device_id][0], &tmpDevicePath[0]);
#endif
						}
					}
					else
					{
						if(tmpReadWriteHandleToUSBDevice != INVALID_HANDLE_VALUE)
						{
							CloseHandle(tmpReadWriteHandleToUSBDevice);
							tmpReadWriteHandleToUSBDevice = INVALID_HANDLE_VALUE;
						}
					}
				}
			}
			else
			{
				//SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				free(pDetailedInterfaceDataStructure);
				break;
				//return FALSE;
			}
		}

		InterfaceIndex++;	
		//Keep looping until we either find a device with matching VID and PID, or until we run out of devices to check.
		//However, just in case some unexpected error occurs, keep track of the number of loops executed.
		//If the number of loops exceeds a very large number, exit anyway, to prevent inadvertent infinite looping.
		LoopCounter++;
		if(LoopCounter == 10000000)	//Surely there aren't more than 10 million devices attached to any forseeable PC...
		{
			break;
			//return FALSE;
		}
		// ID��v�Ȃ�I��
		if (device_id_found == true)
		{
			break;
		}
	}//end of while(true)

	if(DeviceInfoTable >= 0)
	{
		SetupDiDestroyDeviceInfoList(DeviceInfoTable);
	}
	delete InterfaceDataStructure;

    if (device_id_found == true)
    {
        return true;
    }
    else
    {
        DevicePath[device_id][0] = 0x00;
        return false;
    }
}

HANDLE __stdcall openUSBLEDController(HANDLE hRecipient, int device_id)
{
	//PSP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA;	//Global

	//DEV_BROADCAST_DEVICEINTERFACE MyDeviceBroadcastHeader;// = new DEV_BROADCAST_HDR;
	//MyDeviceBroadcastHeader.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
	//MyDeviceBroadcastHeader.dbcc_size = sizeof(DEV_BROADCAST_DEVICEINTERFACE);
	//MyDeviceBroadcastHeader.dbcc_reserved = 0;	//Reserved says not to use...
	//MyDeviceBroadcastHeader.dbcc_classguid = InterfaceClassGuid;
	//RegisterDeviceNotification(hRecipient, &MyDeviceBroadcastHeader, DEVICE_NOTIFY_WINDOW_HANDLE);

	if(0 <= device_id && device_id < DEVICE_ID_NUM)
	{

		if(CheckIfPresentAndGetUSBDevicePath(device_id))	//Check and make sure at least one device with matching VID/PID is attached
		{	// USB�f�o�C�X��������
			if(AttachedState[device_id] == FALSE)
			{
				DWORD ErrorStatusReadWrite;

				//We now have the proper device path, and we can finally open read and write handles to the device.
				ReadWriteHandleToUSBDevice[device_id] = CreateFile(DevicePath[device_id], GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, 0);
				ErrorStatusReadWrite = GetLastError();
				if(ErrorStatusReadWrite == ERROR_SUCCESS)
				{
					AttachedState[device_id] = TRUE;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
				}
				else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
				{
					AttachedState[device_id] = FALSE;		//Let the rest of this application known not to read/write to the device.

					if(ReadWriteHandleToUSBDevice[device_id] != INVALID_HANDLE_VALUE)
					{
						CloseHandle(ReadWriteHandleToUSBDevice[device_id]);
						ReadWriteHandleToUSBDevice[device_id] = INVALID_HANDLE_VALUE;
					}
				}
			}
			else
			{
			}
		}
		else	//Device must not be connected (or not programmed with correct firmware)
		{	// USB�f�o�C�X�Ȃ�
			AttachedState[device_id] = FALSE;

			if(ReadWriteHandleToUSBDevice[device_id] != INVALID_HANDLE_VALUE)
			{
				CloseHandle(ReadWriteHandleToUSBDevice[device_id]);
				ReadWriteHandleToUSBDevice[device_id] = INVALID_HANDLE_VALUE;
			}
		}
		// �ڑ�����
		if(AttachedState[device_id] == TRUE)
		{
			return ReadWriteHandleToUSBDevice[device_id];
		}
		else
		{
			return NULL;
		}
	}
	else
	{
		return NULL;
	}

}

int __stdcall closeUSBLEDController(HANDLE HandleToUSBDevice, int device_id)
{
	int i_ret = 0;

	if(0 <= device_id && device_id < DEVICE_ID_NUM)
	{
		if(ReadWriteHandleToUSBDevice[device_id] != INVALID_HANDLE_VALUE && HandleToUSBDevice != NULL && ReadWriteHandleToUSBDevice[device_id] == HandleToUSBDevice)
		{
			AttachedState[device_id] = FALSE;

			CloseHandle(ReadWriteHandleToUSBDevice[device_id]);
			ReadWriteHandleToUSBDevice[device_id] = INVALID_HANDLE_VALUE;
		}
		else
		{
			i_ret = -1;
		}
	}
	else
	{
		i_ret = -1;
	}

	return i_ret;
}

int __stdcall writeLEDOutput(HANDLE HandleToUSBDevice, int device_id, int led_no, BYTE set_duty)
{
	int i_ret_val = -1;
	BYTE OUTBuffer[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
	BYTE INBuffer[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
	DWORD BytesWritten = 0;
	DWORD BytesRead = 0;
	BYTE set_led_no = 0;
	
    // �p�����[�^�[�`�F�b�N
    bool para_check = false;
	if(device_id < LED_DEVICE_ID_MIN || LED_DEVICE_ID_MAX < device_id )
	{
		para_check = true;
	}
	if(led_no < LED_NO_MIN || LED_NO_MAX < led_no )
	{
		para_check = true;
	}
	else
	{
		set_led_no = (BYTE)(led_no & 0xFF);
		set_led_no = set_led_no - LED_NO_MIN;
	}
	if(para_check == false)
	{
		if(ReadWriteHandleToUSBDevice[device_id] != INVALID_HANDLE_VALUE && HandleToUSBDevice != NULL && ReadWriteHandleToUSBDevice[device_id] == HandleToUSBDevice)
		{
			for(int fi = 0; fi < 65; fi++)
			{
				OUTBuffer[fi] = 0xFF;
			}

			OUTBuffer[0] = 0;
			OUTBuffer[1] = 0x22;
			OUTBuffer[2] = set_led_no;
			OUTBuffer[3] = set_duty;

			if (WriteFile(HandleToUSBDevice, &OUTBuffer, 65, &BytesWritten, 0))
			{
				INBuffer[0] = 0;
				if (ReadFile(HandleToUSBDevice, &INBuffer, 65, &BytesRead, 0))
				{
					if (INBuffer[1] == 0x22)
					{
                        if (INBuffer[2] == 0x00)
                        {
                            i_ret_val = 0;
                        }
						else
						{
							//i_ret_val = -7;
						}
					}
					else
					{
						//i_ret_val = -6;

					}
				}
				else
				{
					//i_ret_val = -5;
				}
			}
			else
			{
				//i_ret_val = -4;
			}
		}
		else
		{
			//i_ret_val = -3;
		}
	}
	else
	{
		//i_ret_val = -2;
	}
	return i_ret_val;
}

int __stdcall writeLEDOutputAll(HANDLE HandleToUSBDevice, int device_id, BYTE* set_duty, int set_duty_len)
{
	int i_ret_val = -1;
	BYTE OUTBuffer[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
	BYTE INBuffer[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
	DWORD BytesWritten = 0;
	DWORD BytesRead = 0;
	
    // �p�����[�^�[�`�F�b�N
    bool para_check = false;
	if(device_id < LED_DEVICE_ID_MIN || LED_DEVICE_ID_MAX < device_id )
	{
		para_check = true;
	}
	if(set_duty_len != LED_NUM)
	{
		para_check = true;
	}
	if(para_check == false)
	{
        // �o�͒l�`�F�b�N
        bool error_check = false;
        for (int fi = 0; fi < set_duty_len; fi++)
        {
            if (set_duty[fi] > LED_DUTY_MAX)
            {
                set_duty[fi] = LED_DUTY_MAX;
            }
        }
		if(ReadWriteHandleToUSBDevice[device_id] != INVALID_HANDLE_VALUE && HandleToUSBDevice != NULL && ReadWriteHandleToUSBDevice[device_id] == HandleToUSBDevice)
		{
			for(int fi = 0; fi < 65; fi++)
			{
				OUTBuffer[fi] = 0xFF;
			}

			OUTBuffer[0] = 0;
			OUTBuffer[1] = 0x31;
			for (int fi = 0; fi < set_duty_len; fi++)
			{
				OUTBuffer[2 + fi] = set_duty[fi];
			}

			if (WriteFile(HandleToUSBDevice, &OUTBuffer, 65, &BytesWritten, 0))
			{
				INBuffer[0] = 0;
				if (ReadFile(HandleToUSBDevice, &INBuffer, 65, &BytesRead, 0))
				{
					if (INBuffer[1] == 0x31)
					{
                        if (INBuffer[2] == 0x00)
                        {
                            i_ret_val = 0;
                        }
						else
						{
							//i_ret_val = -7;
						}
					}
					else
					{
						//i_ret_val = -6;

					}
				}
				else
				{
					//i_ret_val = -5;
				}
			}
			else
			{
				//i_ret_val = -4;
			}
		}
		else
		{
			//i_ret_val = -3;
		}
	}
	else
	{
		//i_ret_val = -2;
	}
	return i_ret_val;
}


int __stdcall readLEDData(HANDLE HandleToUSBDevice, int device_id, BYTE* led_duty, int read_led_num)
{
	int i_ret_val = -1;
	BYTE OUTBuffer[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
	BYTE INBuffer[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
	DWORD BytesWritten = 0;
	DWORD BytesRead = 0;
	int set_read_relay_num = 0;
	
    // �p�����[�^�[�`�F�b�N
    bool para_check = false;
	if(device_id < LED_DEVICE_ID_MIN || LED_DEVICE_ID_MAX < device_id )
	{
		para_check = true;
	}
	if(read_led_num != LED_NUM)
	{
		para_check = true;
	}
	if(para_check == false)
	{
        // �o�̓o�b�t�@������
        bool error_check = false;
        for (int fi = 0; fi < read_led_num; fi++)
        {
            led_duty[fi] = 0;
        }
		if(ReadWriteHandleToUSBDevice[device_id] != INVALID_HANDLE_VALUE && HandleToUSBDevice != NULL && ReadWriteHandleToUSBDevice[device_id] == HandleToUSBDevice)
		{
			for(int fi = 0; fi < 65; fi++)
			{
				OUTBuffer[fi] = 0xFF;
			}

			OUTBuffer[0] = 0;
			OUTBuffer[1] = 0x21;

			if (WriteFile(HandleToUSBDevice, &OUTBuffer, 65, &BytesWritten, 0))
			{
				INBuffer[0] = 0;
				if (ReadFile(HandleToUSBDevice, &INBuffer, 65, &BytesRead, 0))
				{
					if (INBuffer[1] == 0x21)
					{
                        for (int fi = 0; fi < read_led_num; fi++)
                        {
                            led_duty[fi] = INBuffer[2 + fi];
                        }
                        i_ret_val = 0;
					}
					else
					{
						//i_ret_val = -6;

					}
				}
				else
				{
					//i_ret_val = -5;
				}
			}
			else
			{
				//i_ret_val = -4;
			}
		}
		else
		{
			//i_ret_val = -3;
		}
	}
	else
	{
		//i_ret_val = -2;
	}
	return i_ret_val;
}


