// USBLEDControllerLibSample.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "USBLEDControllerLib.h"

#define DEVICE_ID_NUM	5

#define LED_CONNECT_MAX_NUM		0x05	// LED�ڑ��ő吔
#define LED_DEVICE_ID_MIN		0x00	// LED DEVICE ID MIN
#define LED_DEVICE_ID_MAX		0x04	// LED DEVICE ID MAX
#define LED1_DEVICE_ID			0x00	// LED1 DEVICE ID
#define LED2_DEVICE_ID			0x01	// LED2 DEVICE ID
#define LED3_DEVICE_ID			0x02	// LED3 DEVICE ID
#define LED4_DEVICE_ID			0x03	// LED4 DEVICE ID
#define LED5_DEVICE_ID			0x04	// LED5 DEVICE ID
#define LED_NO_MIN				0x01	// LED NO MIN
#define LED_NO_MAX				0x0A	// LED NO MAX
#define LED_NUM					0x0A	// LED��

int _tmain(int argc, _TCHAR* argv[])
{
	int type = 0;
	int d_id = 0;
	int set_val = 0;
	int i_ret;
	int para1, para2;
	BYTE* para_arry;
	BYTE para_set_duty_arry[LED_NUM];
	int fi;
	BYTE check_flag = 0;
	clock_t start_time, end_time;

	HMODULE hHandle = GetModuleHandle(0);
	//openUSB(hHandle);
	HANDLE usbHandle[DEVICE_ID_NUM] = {NULL};

	while(1)
	{
		printf_s("\n�������e��I�����ĉ������B\n");
		printf("1:USB�ڑ�\n");
		printf("2:USB�ؒf\n");
		printf("3:LED�o�͐ݒ�\n");
		printf("4:LED�S�o�͐ݒ�\n");
		printf("5:LED�o�͏�Ԏ擾\n");
		printf("99:�I��\n");
		rewind(stdin);
		type = 0;
		printf("�����ԍ� ? = ");
		scanf_s("%d", &type);

		if(type == 99)
		{
			break;
		}

		do{
			printf("Device ID ? (0�`4) = ");
			scanf_s("%d", &d_id);
		}while(d_id < 0 || DEVICE_ID_NUM <= d_id);



		switch(type)
		{
			case 1:
				start_time = clock();
				usbHandle[d_id] = openUSBLEDController(hHandle, d_id);
				end_time = clock();
				printf("%d\n", usbHandle[d_id]);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 2:
				start_time = clock();
				i_ret = closeUSBLEDController(usbHandle[d_id], d_id);
				end_time = clock();
				usbHandle[d_id] = NULL;
				printf("%d\n", i_ret);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 3:
				printf("LED No. ? (1�`10) = ");
				scanf_s("%d", &para1);
				printf("LED Set Duty ? (0�`100) = ");
				scanf_s("%d", &para2);
				if(para2 < 0)
				{
					para2 = 0;
				}
				else if(para2 > 100)
				{
					para2 = 100;
				}
				start_time = clock();
				i_ret = writeLEDOutput(usbHandle[d_id], d_id, para1, para2);
				end_time = clock();
				printf("%d\n", i_ret);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 4:
				check_flag	= 0;
				for(fi = 0; fi < LED_NUM; fi++)
				{
					printf("LED %d Set Duty ? (0�`100) = ", fi+1);
					scanf_s("%d", &para2);
					if(para2 < 0)
					{
						para2 = 0;
					}
					if(para2 > 100)
					{
						para2 = 100;
					}
					para_set_duty_arry[fi] = (BYTE)(para2 & 0xFF);
				}
				if(check_flag == 0)
				{
					start_time = clock();
					i_ret = writeLEDOutputAll(usbHandle[d_id], d_id, para_set_duty_arry, LED_NUM);
					end_time = clock();
					printf("%d\n", i_ret);
					printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				}
				break;
			case 5:
				check_flag	= 0;
				for(fi = 0; fi < LED_NUM; fi++)
				{
					para_set_duty_arry[fi] = 0;
				}
				if(check_flag == 0)
				{
					start_time = clock();
					i_ret = readLEDData(usbHandle[d_id], d_id, para_set_duty_arry, LED_NUM);
					end_time = clock();
					for(fi = 0; fi < LED_NUM; fi++)
					{
						printf("%d ", para_set_duty_arry[fi]);
					}
					printf("\n");
					printf("%d\n", i_ret);
					printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				}
				break;
			default:
				printf("\n�����ԍ�������������܂���I�I�I\n\n");
				break;

		}

	}

	// Open���Ă���USB���N���[�Y����
	for(int fi = 0; fi < DEVICE_ID_NUM; fi++)
	{
		if(usbHandle[d_id] != NULL)
		{
			i_ret = closeUSBLEDController(usbHandle[d_id], fi);
		}
	}

	return 0;
}

