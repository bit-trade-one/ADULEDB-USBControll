﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32.SafeHandles;
using USB_LED_Controller_Library;

namespace USB_LED_Controller_sample
{
    public partial class Form1 : Form
    {
        const int LED_NUM = 10;
        const int DEVICE_MAX_NUM = 5;
        NumericUpDown[] num_LED_duty;
        TextBox[] txtbx_LED_Duty;
        NumericUpDown[] num_LED_duty2;
        TextBox[] txtbx_LED_Duty2;

        public Form1()
        {
            InitializeComponent();

            num_LED_duty = new NumericUpDown[LED_NUM] { numericUpDown1, numericUpDown2, numericUpDown3, numericUpDown4, numericUpDown5, numericUpDown6, numericUpDown7, numericUpDown8, numericUpDown9, numericUpDown10 };
            txtbx_LED_Duty = new TextBox[LED_NUM] { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7, textBox8, textBox9, textBox10 };
            num_LED_duty2 = new NumericUpDown[LED_NUM] { numericUpDown20, numericUpDown19, numericUpDown18, numericUpDown17, numericUpDown16, numericUpDown15, numericUpDown14, numericUpDown13, numericUpDown12, numericUpDown11 };
            txtbx_LED_Duty2 = new TextBox[LED_NUM] { textBox20, textBox19, textBox18, textBox17, textBox16, textBox15, textBox14, textBox13, textBox12, textBox11 };

            for(int fi = 0; fi < DEVICE_MAX_NUM; fi++)
            {
                comboBox1.Items.Add(string.Format("Device ID = {0}", fi + 1));
            }
            comboBox1.SelectedIndex = 0;
        }

        private void btn_duty_allset_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBLEDController.openUSBLEDController(this.Handle, 1);
                if (handle_usb_device != null)
                {
                    byte[] set_duty = new byte[num_LED_duty.Length];
                    for(int fi = 0; fi < num_LED_duty.Length; fi++)
                    {
                        set_duty[fi] = (byte)((int)(num_LED_duty[fi].Value) & 0xFF);
                    }
                    i_ret = USBLEDController.writeLEDAllData(handle_usb_device, 1, set_duty);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, 1);
                }
            }
        }

        private void btn_duty_set_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                int idx = int.Parse(((Button)sender).Tag.ToString());
                // USB DEVICEオープン
                handle_usb_device = USBLEDController.openUSBLEDController(this.Handle, 1);
                if (handle_usb_device != null)
                {
                    byte set_duty = (byte)((int)(num_LED_duty[idx].Value) & 0xFF);
                    i_ret = USBLEDController.writeLEDData(handle_usb_device, 1, idx + 1, set_duty);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, 1);
                }
            }
        }

        private void btn_duty_read_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBLEDController.openUSBLEDController(this.Handle, 1);
                if (handle_usb_device != null)
                {
                    byte[] read_duty = new byte[LED_NUM];
                    i_ret = USBLEDController.readLEDData(handle_usb_device, 1, ref read_duty, LED_NUM);
                    for (int fi = 0; fi < LED_NUM; fi++)
                    {
                        txtbx_LED_Duty[fi].Text = read_duty[fi].ToString();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, 1);
                }
            }
        }

        private void btn_duty_allset2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            int device_idx = comboBox1.SelectedIndex;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBLEDController.openUSBLEDController(this.Handle, device_idx + 1);
                if (handle_usb_device != null)
                {
                    byte[] set_duty = new byte[num_LED_duty.Length];
                    for (int fi = 0; fi < num_LED_duty.Length; fi++)
                    {
                        set_duty[fi] = (byte)((int)(num_LED_duty2[fi].Value) & 0xFF);
                    }
                    i_ret = USBLEDController.writeLEDAllData(handle_usb_device, device_idx + 1, set_duty);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, device_idx + 1);
                }
            }
        }

        private void btn_duty_set2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            int device_idx = comboBox1.SelectedIndex;
            try
            {
                int idx = int.Parse(((Button)sender).Tag.ToString());
                // USB DEVICEオープン
                handle_usb_device = USBLEDController.openUSBLEDController(this.Handle, device_idx + 1);
                if (handle_usb_device != null)
                {
                    byte set_duty = (byte)((int)(num_LED_duty2[idx].Value) & 0xFF);
                    i_ret = USBLEDController.writeLEDData(handle_usb_device, device_idx + 1, idx + 1, set_duty);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, device_idx + 1);
                }
            }
        }

        private void btn_duty_read2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            int device_idx = comboBox1.SelectedIndex;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBLEDController.openUSBLEDController(this.Handle, device_idx + 1);
                if (handle_usb_device != null)
                {
                    byte[] read_duty = new byte[LED_NUM];
                    i_ret = USBLEDController.readLEDData(handle_usb_device, device_idx + 1, ref read_duty, LED_NUM);
                    for (int fi = 0; fi < LED_NUM; fi++)
                    {
                        txtbx_LED_Duty2[fi].Text = read_duty[fi].ToString();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBLEDController.closeUSBLEDController(handle_usb_device, device_idx + 1);
                }
            }
        }
    }
}
