﻿namespace USB_LED_Controller_sample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btn_duty_read = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_duty_allset = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_duty_set10 = new System.Windows.Forms.Button();
            this.btn_duty_set9 = new System.Windows.Forms.Button();
            this.btn_duty_set8 = new System.Windows.Forms.Button();
            this.btn_duty_set7 = new System.Windows.Forms.Button();
            this.btn_duty_set6 = new System.Windows.Forms.Button();
            this.btn_duty_set5 = new System.Windows.Forms.Button();
            this.btn_duty_set4 = new System.Windows.Forms.Button();
            this.btn_duty_set3 = new System.Windows.Forms.Button();
            this.btn_duty_set2 = new System.Windows.Forms.Button();
            this.btn_duty_set1 = new System.Windows.Forms.Button();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btn_duty_read2 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.btn_duty_allset2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown13 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown14 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown15 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown16 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown17 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown18 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown19 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown20 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.btn_duty_read);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.btn_duty_allset);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btn_duty_set10);
            this.groupBox1.Controls.Add(this.btn_duty_set9);
            this.groupBox1.Controls.Add(this.btn_duty_set8);
            this.groupBox1.Controls.Add(this.btn_duty_set7);
            this.groupBox1.Controls.Add(this.btn_duty_set6);
            this.groupBox1.Controls.Add(this.btn_duty_set5);
            this.groupBox1.Controls.Add(this.btn_duty_set4);
            this.groupBox1.Controls.Add(this.btn_duty_set3);
            this.groupBox1.Controls.Add(this.btn_duty_set2);
            this.groupBox1.Controls.Add(this.btn_duty_set1);
            this.groupBox1.Controls.Add(this.numericUpDown10);
            this.groupBox1.Controls.Add(this.numericUpDown9);
            this.groupBox1.Controls.Add(this.numericUpDown8);
            this.groupBox1.Controls.Add(this.numericUpDown7);
            this.groupBox1.Controls.Add(this.numericUpDown6);
            this.groupBox1.Controls.Add(this.numericUpDown5);
            this.groupBox1.Controls.Add(this.numericUpDown4);
            this.groupBox1.Controls.Add(this.numericUpDown3);
            this.groupBox1.Controls.Add(this.numericUpDown2);
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(835, 160);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LED設定 （１台接続時 Device ID = 1）";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 106);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 21;
            this.label13.Text = "現在値";
            // 
            // btn_duty_read
            // 
            this.btn_duty_read.Location = new System.Drawing.Point(746, 101);
            this.btn_duty_read.Name = "btn_duty_read";
            this.btn_duty_read.Size = new System.Drawing.Size(76, 23);
            this.btn_duty_read.TabIndex = 43;
            this.btn_duty_read.Tag = "0";
            this.btn_duty_read.Text = "read";
            this.btn_duty_read.UseVisualStyleBackColor = true;
            this.btn_duty_read.Click += new System.EventHandler(this.btn_duty_read_Click);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(666, 103);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(60, 19);
            this.textBox10.TabIndex = 42;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(600, 103);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(60, 19);
            this.textBox9.TabIndex = 41;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(534, 103);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(60, 19);
            this.textBox8.TabIndex = 40;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(468, 103);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(60, 19);
            this.textBox7.TabIndex = 39;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(402, 103);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(60, 19);
            this.textBox6.TabIndex = 38;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(336, 103);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(60, 19);
            this.textBox5.TabIndex = 37;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(270, 103);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(60, 19);
            this.textBox4.TabIndex = 36;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(204, 103);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(60, 19);
            this.textBox3.TabIndex = 35;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(138, 103);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(60, 19);
            this.textBox2.TabIndex = 34;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(72, 103);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(60, 19);
            this.textBox1.TabIndex = 33;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_duty_allset
            // 
            this.btn_duty_allset.Location = new System.Drawing.Point(746, 36);
            this.btn_duty_allset.Name = "btn_duty_allset";
            this.btn_duty_allset.Size = new System.Drawing.Size(76, 23);
            this.btn_duty_allset.TabIndex = 32;
            this.btn_duty_allset.Text = "一括設定";
            this.btn_duty_allset.UseVisualStyleBackColor = true;
            this.btn_duty_allset.Click += new System.EventHandler(this.btn_duty_allset_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 12);
            this.label12.TabIndex = 31;
            this.label12.Text = "LED Duty";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(664, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 12);
            this.label11.TabIndex = 30;
            this.label11.Text = "10";
            this.label11.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(598, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 12);
            this.label10.TabIndex = 29;
            this.label10.Text = "9";
            this.label10.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(532, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 12);
            this.label9.TabIndex = 28;
            this.label9.Text = "8";
            this.label9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(468, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 12);
            this.label8.TabIndex = 27;
            this.label8.Text = "7";
            this.label8.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(402, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 12);
            this.label7.TabIndex = 26;
            this.label7.Text = "6";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(336, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 12);
            this.label6.TabIndex = 25;
            this.label6.Text = "5";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(270, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 12);
            this.label5.TabIndex = 24;
            this.label5.Text = "4";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(204, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 12);
            this.label4.TabIndex = 23;
            this.label4.Text = "3";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(138, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 12);
            this.label3.TabIndex = 22;
            this.label3.Text = "2";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(72, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 12);
            this.label2.TabIndex = 21;
            this.label2.Text = "1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 20;
            this.label1.Text = "LED ID";
            // 
            // btn_duty_set10
            // 
            this.btn_duty_set10.Location = new System.Drawing.Point(666, 65);
            this.btn_duty_set10.Name = "btn_duty_set10";
            this.btn_duty_set10.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set10.TabIndex = 19;
            this.btn_duty_set10.Tag = "9";
            this.btn_duty_set10.Text = "set";
            this.btn_duty_set10.UseVisualStyleBackColor = true;
            this.btn_duty_set10.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set9
            // 
            this.btn_duty_set9.Location = new System.Drawing.Point(600, 65);
            this.btn_duty_set9.Name = "btn_duty_set9";
            this.btn_duty_set9.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set9.TabIndex = 18;
            this.btn_duty_set9.Tag = "8";
            this.btn_duty_set9.Text = "set";
            this.btn_duty_set9.UseVisualStyleBackColor = true;
            this.btn_duty_set9.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set8
            // 
            this.btn_duty_set8.Location = new System.Drawing.Point(534, 65);
            this.btn_duty_set8.Name = "btn_duty_set8";
            this.btn_duty_set8.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set8.TabIndex = 17;
            this.btn_duty_set8.Tag = "7";
            this.btn_duty_set8.Text = "set";
            this.btn_duty_set8.UseVisualStyleBackColor = true;
            this.btn_duty_set8.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set7
            // 
            this.btn_duty_set7.Location = new System.Drawing.Point(468, 65);
            this.btn_duty_set7.Name = "btn_duty_set7";
            this.btn_duty_set7.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set7.TabIndex = 16;
            this.btn_duty_set7.Tag = "6";
            this.btn_duty_set7.Text = "set";
            this.btn_duty_set7.UseVisualStyleBackColor = true;
            this.btn_duty_set7.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set6
            // 
            this.btn_duty_set6.Location = new System.Drawing.Point(402, 65);
            this.btn_duty_set6.Name = "btn_duty_set6";
            this.btn_duty_set6.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set6.TabIndex = 15;
            this.btn_duty_set6.Tag = "5";
            this.btn_duty_set6.Text = "set";
            this.btn_duty_set6.UseVisualStyleBackColor = true;
            this.btn_duty_set6.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set5
            // 
            this.btn_duty_set5.Location = new System.Drawing.Point(336, 65);
            this.btn_duty_set5.Name = "btn_duty_set5";
            this.btn_duty_set5.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set5.TabIndex = 14;
            this.btn_duty_set5.Tag = "4";
            this.btn_duty_set5.Text = "set";
            this.btn_duty_set5.UseVisualStyleBackColor = true;
            this.btn_duty_set5.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set4
            // 
            this.btn_duty_set4.Location = new System.Drawing.Point(270, 65);
            this.btn_duty_set4.Name = "btn_duty_set4";
            this.btn_duty_set4.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set4.TabIndex = 13;
            this.btn_duty_set4.Tag = "3";
            this.btn_duty_set4.Text = "set";
            this.btn_duty_set4.UseVisualStyleBackColor = true;
            this.btn_duty_set4.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set3
            // 
            this.btn_duty_set3.Location = new System.Drawing.Point(204, 65);
            this.btn_duty_set3.Name = "btn_duty_set3";
            this.btn_duty_set3.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set3.TabIndex = 12;
            this.btn_duty_set3.Tag = "2";
            this.btn_duty_set3.Text = "set";
            this.btn_duty_set3.UseVisualStyleBackColor = true;
            this.btn_duty_set3.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set2
            // 
            this.btn_duty_set2.Location = new System.Drawing.Point(138, 65);
            this.btn_duty_set2.Name = "btn_duty_set2";
            this.btn_duty_set2.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set2.TabIndex = 11;
            this.btn_duty_set2.Tag = "1";
            this.btn_duty_set2.Text = "set";
            this.btn_duty_set2.UseVisualStyleBackColor = true;
            this.btn_duty_set2.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // btn_duty_set1
            // 
            this.btn_duty_set1.Location = new System.Drawing.Point(72, 65);
            this.btn_duty_set1.Name = "btn_duty_set1";
            this.btn_duty_set1.Size = new System.Drawing.Size(60, 23);
            this.btn_duty_set1.TabIndex = 10;
            this.btn_duty_set1.Tag = "0";
            this.btn_duty_set1.Text = "set";
            this.btn_duty_set1.UseVisualStyleBackColor = true;
            this.btn_duty_set1.Click += new System.EventHandler(this.btn_duty_set_Click);
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown10.Location = new System.Drawing.Point(666, 36);
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown10.TabIndex = 9;
            this.numericUpDown10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown9.Location = new System.Drawing.Point(600, 36);
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown9.TabIndex = 8;
            this.numericUpDown9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown8.Location = new System.Drawing.Point(534, 36);
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown8.TabIndex = 7;
            this.numericUpDown8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown7.Location = new System.Drawing.Point(468, 36);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown7.TabIndex = 6;
            this.numericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown6.Location = new System.Drawing.Point(402, 36);
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown6.TabIndex = 5;
            this.numericUpDown6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown5.Location = new System.Drawing.Point(336, 36);
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown5.TabIndex = 4;
            this.numericUpDown5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown4.Location = new System.Drawing.Point(270, 36);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown4.TabIndex = 3;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown3.Location = new System.Drawing.Point(204, 36);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown3.TabIndex = 2;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown2.Location = new System.Drawing.Point(138, 36);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown2.TabIndex = 1;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown1.Location = new System.Drawing.Point(72, 36);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown1.TabIndex = 0;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.btn_duty_read2);
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.textBox12);
            this.groupBox3.Controls.Add(this.textBox13);
            this.groupBox3.Controls.Add(this.textBox14);
            this.groupBox3.Controls.Add(this.textBox15);
            this.groupBox3.Controls.Add(this.textBox16);
            this.groupBox3.Controls.Add(this.textBox17);
            this.groupBox3.Controls.Add(this.textBox18);
            this.groupBox3.Controls.Add(this.textBox19);
            this.groupBox3.Controls.Add(this.textBox20);
            this.groupBox3.Controls.Add(this.btn_duty_allset2);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.button12);
            this.groupBox3.Controls.Add(this.button13);
            this.groupBox3.Controls.Add(this.button14);
            this.groupBox3.Controls.Add(this.button15);
            this.groupBox3.Controls.Add(this.button16);
            this.groupBox3.Controls.Add(this.button17);
            this.groupBox3.Controls.Add(this.button18);
            this.groupBox3.Controls.Add(this.button19);
            this.groupBox3.Controls.Add(this.button20);
            this.groupBox3.Controls.Add(this.button21);
            this.groupBox3.Controls.Add(this.numericUpDown11);
            this.groupBox3.Controls.Add(this.numericUpDown12);
            this.groupBox3.Controls.Add(this.numericUpDown13);
            this.groupBox3.Controls.Add(this.numericUpDown14);
            this.groupBox3.Controls.Add(this.numericUpDown15);
            this.groupBox3.Controls.Add(this.numericUpDown16);
            this.groupBox3.Controls.Add(this.numericUpDown17);
            this.groupBox3.Controls.Add(this.numericUpDown18);
            this.groupBox3.Controls.Add(this.numericUpDown19);
            this.groupBox3.Controls.Add(this.numericUpDown20);
            this.groupBox3.Location = new System.Drawing.Point(12, 178);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(835, 170);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "送信（複数台接続時）";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(93, 18);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 90;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(14, 24);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 12);
            this.label27.TabIndex = 89;
            this.label27.Text = "DEVICE ID";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 138);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 66;
            this.label14.Text = "現在値";
            // 
            // btn_duty_read2
            // 
            this.btn_duty_read2.Location = new System.Drawing.Point(744, 133);
            this.btn_duty_read2.Name = "btn_duty_read2";
            this.btn_duty_read2.Size = new System.Drawing.Size(76, 23);
            this.btn_duty_read2.TabIndex = 88;
            this.btn_duty_read2.Tag = "0";
            this.btn_duty_read2.Text = "read";
            this.btn_duty_read2.UseVisualStyleBackColor = true;
            this.btn_duty_read2.Click += new System.EventHandler(this.btn_duty_read2_Click);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(664, 135);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(60, 19);
            this.textBox11.TabIndex = 87;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(598, 135);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(60, 19);
            this.textBox12.TabIndex = 86;
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(532, 135);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(60, 19);
            this.textBox13.TabIndex = 85;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(466, 135);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(60, 19);
            this.textBox14.TabIndex = 84;
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(400, 135);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(60, 19);
            this.textBox15.TabIndex = 83;
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(334, 135);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(60, 19);
            this.textBox16.TabIndex = 82;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(268, 135);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(60, 19);
            this.textBox17.TabIndex = 81;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(202, 135);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(60, 19);
            this.textBox18.TabIndex = 80;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(136, 135);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(60, 19);
            this.textBox19.TabIndex = 79;
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(70, 135);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(60, 19);
            this.textBox20.TabIndex = 78;
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_duty_allset2
            // 
            this.btn_duty_allset2.Location = new System.Drawing.Point(744, 68);
            this.btn_duty_allset2.Name = "btn_duty_allset2";
            this.btn_duty_allset2.Size = new System.Drawing.Size(76, 23);
            this.btn_duty_allset2.TabIndex = 77;
            this.btn_duty_allset2.Text = "一括設定";
            this.btn_duty_allset2.UseVisualStyleBackColor = true;
            this.btn_duty_allset2.Click += new System.EventHandler(this.btn_duty_allset2_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 74);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 12);
            this.label15.TabIndex = 76;
            this.label15.Text = "LED Duty";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(662, 53);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 12);
            this.label16.TabIndex = 75;
            this.label16.Text = "10";
            this.label16.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(596, 53);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(60, 12);
            this.label17.TabIndex = 74;
            this.label17.Text = "9";
            this.label17.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(530, 53);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 12);
            this.label18.TabIndex = 73;
            this.label18.Text = "8";
            this.label18.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(466, 53);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 12);
            this.label19.TabIndex = 72;
            this.label19.Text = "7";
            this.label19.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(400, 53);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(60, 12);
            this.label20.TabIndex = 71;
            this.label20.Text = "6";
            this.label20.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(334, 53);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 12);
            this.label21.TabIndex = 70;
            this.label21.Text = "5";
            this.label21.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(268, 53);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 12);
            this.label22.TabIndex = 69;
            this.label22.Text = "4";
            this.label22.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(202, 53);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 12);
            this.label23.TabIndex = 68;
            this.label23.Text = "3";
            this.label23.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(136, 53);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 12);
            this.label24.TabIndex = 67;
            this.label24.Text = "2";
            this.label24.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(70, 53);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 12);
            this.label25.TabIndex = 65;
            this.label25.Text = "1";
            this.label25.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(14, 53);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 12);
            this.label26.TabIndex = 64;
            this.label26.Text = "LED ID";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(664, 97);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(60, 23);
            this.button12.TabIndex = 63;
            this.button12.Tag = "9";
            this.button12.Text = "set";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(598, 97);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(60, 23);
            this.button13.TabIndex = 62;
            this.button13.Tag = "8";
            this.button13.Text = "set";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(532, 97);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(60, 23);
            this.button14.TabIndex = 61;
            this.button14.Tag = "7";
            this.button14.Text = "set";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(466, 97);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(60, 23);
            this.button15.TabIndex = 60;
            this.button15.Tag = "6";
            this.button15.Text = "set";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(400, 97);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(60, 23);
            this.button16.TabIndex = 59;
            this.button16.Tag = "5";
            this.button16.Text = "set";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(334, 97);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(60, 23);
            this.button17.TabIndex = 58;
            this.button17.Tag = "4";
            this.button17.Text = "set";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(268, 97);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(60, 23);
            this.button18.TabIndex = 57;
            this.button18.Tag = "3";
            this.button18.Text = "set";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(202, 97);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(60, 23);
            this.button19.TabIndex = 56;
            this.button19.Tag = "2";
            this.button19.Text = "set";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(136, 97);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(60, 23);
            this.button20.TabIndex = 55;
            this.button20.Tag = "1";
            this.button20.Text = "set";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(70, 97);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(60, 23);
            this.button21.TabIndex = 54;
            this.button21.Tag = "0";
            this.button21.Text = "set";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.btn_duty_set2_Click);
            // 
            // numericUpDown11
            // 
            this.numericUpDown11.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown11.Location = new System.Drawing.Point(664, 68);
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown11.TabIndex = 53;
            this.numericUpDown11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown12
            // 
            this.numericUpDown12.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown12.Location = new System.Drawing.Point(598, 68);
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown12.TabIndex = 52;
            this.numericUpDown12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown13
            // 
            this.numericUpDown13.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown13.Location = new System.Drawing.Point(532, 68);
            this.numericUpDown13.Name = "numericUpDown13";
            this.numericUpDown13.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown13.TabIndex = 51;
            this.numericUpDown13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown14
            // 
            this.numericUpDown14.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown14.Location = new System.Drawing.Point(466, 68);
            this.numericUpDown14.Name = "numericUpDown14";
            this.numericUpDown14.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown14.TabIndex = 50;
            this.numericUpDown14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown15
            // 
            this.numericUpDown15.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown15.Location = new System.Drawing.Point(400, 68);
            this.numericUpDown15.Name = "numericUpDown15";
            this.numericUpDown15.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown15.TabIndex = 49;
            this.numericUpDown15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown16
            // 
            this.numericUpDown16.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown16.Location = new System.Drawing.Point(334, 68);
            this.numericUpDown16.Name = "numericUpDown16";
            this.numericUpDown16.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown16.TabIndex = 48;
            this.numericUpDown16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown17
            // 
            this.numericUpDown17.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown17.Location = new System.Drawing.Point(268, 68);
            this.numericUpDown17.Name = "numericUpDown17";
            this.numericUpDown17.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown17.TabIndex = 47;
            this.numericUpDown17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown18
            // 
            this.numericUpDown18.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown18.Location = new System.Drawing.Point(202, 68);
            this.numericUpDown18.Name = "numericUpDown18";
            this.numericUpDown18.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown18.TabIndex = 46;
            this.numericUpDown18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown19
            // 
            this.numericUpDown19.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown19.Location = new System.Drawing.Point(136, 68);
            this.numericUpDown19.Name = "numericUpDown19";
            this.numericUpDown19.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown19.TabIndex = 45;
            this.numericUpDown19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDown20
            // 
            this.numericUpDown20.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.numericUpDown20.Location = new System.Drawing.Point(70, 68);
            this.numericUpDown20.Name = "numericUpDown20";
            this.numericUpDown20.Size = new System.Drawing.Size(60, 23);
            this.numericUpDown20.TabIndex = 44;
            this.numericUpDown20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(858, 360);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "USB LED Controller ライブラリサンプル";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_duty_set10;
        private System.Windows.Forms.Button btn_duty_set9;
        private System.Windows.Forms.Button btn_duty_set8;
        private System.Windows.Forms.Button btn_duty_set7;
        private System.Windows.Forms.Button btn_duty_set6;
        private System.Windows.Forms.Button btn_duty_set5;
        private System.Windows.Forms.Button btn_duty_set4;
        private System.Windows.Forms.Button btn_duty_set3;
        private System.Windows.Forms.Button btn_duty_set2;
        private System.Windows.Forms.Button btn_duty_set1;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_duty_allset;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_duty_read;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btn_duty_read2;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Button btn_duty_allset2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.NumericUpDown numericUpDown11;
        private System.Windows.Forms.NumericUpDown numericUpDown12;
        private System.Windows.Forms.NumericUpDown numericUpDown13;
        private System.Windows.Forms.NumericUpDown numericUpDown14;
        private System.Windows.Forms.NumericUpDown numericUpDown15;
        private System.Windows.Forms.NumericUpDown numericUpDown16;
        private System.Windows.Forms.NumericUpDown numericUpDown17;
        private System.Windows.Forms.NumericUpDown numericUpDown18;
        private System.Windows.Forms.NumericUpDown numericUpDown19;
        private System.Windows.Forms.NumericUpDown numericUpDown20;
    }
}

