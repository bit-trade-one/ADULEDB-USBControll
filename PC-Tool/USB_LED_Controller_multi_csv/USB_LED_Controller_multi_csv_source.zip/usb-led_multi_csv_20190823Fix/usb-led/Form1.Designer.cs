﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.gbx_fileselect1 = new System.Windows.Forms.GroupBox();
            this.txtbx_file_read_result1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbx_file_path1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_file_select1 = new System.Windows.Forms.Button();
            this.chkbx_loop1 = new System.Windows.Forms.CheckBox();
            this.btn_LED_Control_Start_Stop = new System.Windows.Forms.Button();
            this.lbl_FW_Version1 = new System.Windows.Forms.Label();
            this.lbl_Status1 = new System.Windows.Forms.Label();
            this.FormUpdateTimer_Tick = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.lbl_Status2 = new System.Windows.Forms.Label();
            this.lbl_Status3 = new System.Windows.Forms.Label();
            this.lbl_Status4 = new System.Windows.Forms.Label();
            this.lbl_Status5 = new System.Windows.Forms.Label();
            this.lbl_FW_Version2 = new System.Windows.Forms.Label();
            this.lbl_FW_Version3 = new System.Windows.Forms.Label();
            this.lbl_FW_Version4 = new System.Windows.Forms.Label();
            this.lbl_FW_Version5 = new System.Windows.Forms.Label();
            this.gbx_fileselect2 = new System.Windows.Forms.GroupBox();
            this.txtbx_file_read_result2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbx_file_path2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btn_file_select2 = new System.Windows.Forms.Button();
            this.chkbx_loop2 = new System.Windows.Forms.CheckBox();
            this.gbx_fileselect3 = new System.Windows.Forms.GroupBox();
            this.txtbx_file_read_result3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtbx_file_path3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btn_file_select3 = new System.Windows.Forms.Button();
            this.chkbx_loop3 = new System.Windows.Forms.CheckBox();
            this.gbx_fileselect4 = new System.Windows.Forms.GroupBox();
            this.txtbx_file_read_result4 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtbx_file_path4 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btn_file_select4 = new System.Windows.Forms.Button();
            this.chkbx_loop4 = new System.Windows.Forms.CheckBox();
            this.gbx_fileselect5 = new System.Windows.Forms.GroupBox();
            this.txtbx_file_read_result5 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtbx_file_path5 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.btn_file_select5 = new System.Windows.Forms.Button();
            this.chkbx_loop5 = new System.Windows.Forms.CheckBox();
            this.gbx_fileselect1.SuspendLayout();
            this.gbx_fileselect2.SuspendLayout();
            this.gbx_fileselect3.SuspendLayout();
            this.gbx_fileselect4.SuspendLayout();
            this.gbx_fileselect5.SuspendLayout();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // gbx_fileselect1
            // 
            this.gbx_fileselect1.Controls.Add(this.txtbx_file_read_result1);
            this.gbx_fileselect1.Controls.Add(this.label2);
            this.gbx_fileselect1.Controls.Add(this.txtbx_file_path1);
            this.gbx_fileselect1.Controls.Add(this.label1);
            this.gbx_fileselect1.Controls.Add(this.btn_file_select1);
            this.gbx_fileselect1.Controls.Add(this.chkbx_loop1);
            this.gbx_fileselect1.Location = new System.Drawing.Point(10, 10);
            this.gbx_fileselect1.Name = "gbx_fileselect1";
            this.gbx_fileselect1.Size = new System.Drawing.Size(728, 70);
            this.gbx_fileselect1.TabIndex = 100;
            this.gbx_fileselect1.TabStop = false;
            this.gbx_fileselect1.Tag = "0";
            this.gbx_fileselect1.Text = "制御基板No.1 ファイル指定";
            this.gbx_fileselect1.DragDrop += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragDrop);
            this.gbx_fileselect1.DragOver += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragOver);
            // 
            // txtbx_file_read_result1
            // 
            this.txtbx_file_read_result1.Location = new System.Drawing.Point(128, 41);
            this.txtbx_file_read_result1.Name = "txtbx_file_read_result1";
            this.txtbx_file_read_result1.ReadOnly = true;
            this.txtbx_file_read_result1.Size = new System.Drawing.Size(513, 19);
            this.txtbx_file_read_result1.TabIndex = 111;
            this.txtbx_file_read_result1.TabStop = false;
            this.txtbx_file_read_result1.Tag = "0";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(22, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 110;
            this.label2.Text = "読み込み結果";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_file_path1
            // 
            this.txtbx_file_path1.Location = new System.Drawing.Point(63, 17);
            this.txtbx_file_path1.Name = "txtbx_file_path1";
            this.txtbx_file_path1.ReadOnly = true;
            this.txtbx_file_path1.Size = new System.Drawing.Size(578, 19);
            this.txtbx_file_path1.TabIndex = 102;
            this.txtbx_file_path1.TabStop = false;
            this.txtbx_file_path1.Tag = "0";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(15, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 23);
            this.label1.TabIndex = 101;
            this.label1.Text = "File";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_file_select1
            // 
            this.btn_file_select1.Location = new System.Drawing.Point(643, 15);
            this.btn_file_select1.Name = "btn_file_select1";
            this.btn_file_select1.Size = new System.Drawing.Size(75, 23);
            this.btn_file_select1.TabIndex = 103;
            this.btn_file_select1.Tag = "0";
            this.btn_file_select1.Text = "選択";
            this.btn_file_select1.UseVisualStyleBackColor = true;
            this.btn_file_select1.Click += new System.EventHandler(this.btn_file_select_Click);
            // 
            // chkbx_loop1
            // 
            this.chkbx_loop1.AutoSize = true;
            this.chkbx_loop1.Location = new System.Drawing.Point(657, 44);
            this.chkbx_loop1.Name = "chkbx_loop1";
            this.chkbx_loop1.Size = new System.Drawing.Size(48, 16);
            this.chkbx_loop1.TabIndex = 112;
            this.chkbx_loop1.Tag = "0";
            this.chkbx_loop1.Text = "Loop";
            this.chkbx_loop1.UseVisualStyleBackColor = true;
            this.chkbx_loop1.CheckedChanged += new System.EventHandler(this.chkbx_loop_CheckedChanged);
            // 
            // btn_LED_Control_Start_Stop
            // 
            this.btn_LED_Control_Start_Stop.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_LED_Control_Start_Stop.Location = new System.Drawing.Point(259, 390);
            this.btn_LED_Control_Start_Stop.Name = "btn_LED_Control_Start_Stop";
            this.btn_LED_Control_Start_Stop.Size = new System.Drawing.Size(231, 29);
            this.btn_LED_Control_Start_Stop.TabIndex = 600;
            this.btn_LED_Control_Start_Stop.Text = "LED制御開始";
            this.btn_LED_Control_Start_Stop.UseVisualStyleBackColor = true;
            this.btn_LED_Control_Start_Stop.Click += new System.EventHandler(this.btn_LED_Control_Start_Stop_Click);
            // 
            // lbl_FW_Version1
            // 
            this.lbl_FW_Version1.Location = new System.Drawing.Point(543, 424);
            this.lbl_FW_Version1.Name = "lbl_FW_Version1";
            this.lbl_FW_Version1.Size = new System.Drawing.Size(187, 18);
            this.lbl_FW_Version1.TabIndex = 901;
            this.lbl_FW_Version1.Text = "version";
            this.lbl_FW_Version1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lbl_Status1
            // 
            this.lbl_Status1.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_Status1.Location = new System.Drawing.Point(9, 424);
            this.lbl_Status1.Name = "lbl_Status1";
            this.lbl_Status1.Size = new System.Drawing.Size(380, 18);
            this.lbl_Status1.TabIndex = 900;
            this.lbl_Status1.Text = "status";
            this.lbl_Status1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // FormUpdateTimer_Tick
            // 
            this.FormUpdateTimer_Tick.Enabled = true;
            this.FormUpdateTimer_Tick.Tick += new System.EventHandler(this.FormUpdateTimer_Tick_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // lbl_Status2
            // 
            this.lbl_Status2.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_Status2.Location = new System.Drawing.Point(9, 442);
            this.lbl_Status2.Name = "lbl_Status2";
            this.lbl_Status2.Size = new System.Drawing.Size(380, 18);
            this.lbl_Status2.TabIndex = 910;
            this.lbl_Status2.Text = "status";
            this.lbl_Status2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_Status3
            // 
            this.lbl_Status3.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_Status3.Location = new System.Drawing.Point(9, 460);
            this.lbl_Status3.Name = "lbl_Status3";
            this.lbl_Status3.Size = new System.Drawing.Size(380, 18);
            this.lbl_Status3.TabIndex = 920;
            this.lbl_Status3.Text = "status";
            this.lbl_Status3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_Status4
            // 
            this.lbl_Status4.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_Status4.Location = new System.Drawing.Point(9, 478);
            this.lbl_Status4.Name = "lbl_Status4";
            this.lbl_Status4.Size = new System.Drawing.Size(380, 18);
            this.lbl_Status4.TabIndex = 930;
            this.lbl_Status4.Text = "status";
            this.lbl_Status4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_Status5
            // 
            this.lbl_Status5.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_Status5.Location = new System.Drawing.Point(9, 496);
            this.lbl_Status5.Name = "lbl_Status5";
            this.lbl_Status5.Size = new System.Drawing.Size(380, 18);
            this.lbl_Status5.TabIndex = 940;
            this.lbl_Status5.Text = "status";
            this.lbl_Status5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_FW_Version2
            // 
            this.lbl_FW_Version2.Location = new System.Drawing.Point(543, 442);
            this.lbl_FW_Version2.Name = "lbl_FW_Version2";
            this.lbl_FW_Version2.Size = new System.Drawing.Size(187, 18);
            this.lbl_FW_Version2.TabIndex = 911;
            this.lbl_FW_Version2.Text = "version";
            this.lbl_FW_Version2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lbl_FW_Version3
            // 
            this.lbl_FW_Version3.Location = new System.Drawing.Point(543, 460);
            this.lbl_FW_Version3.Name = "lbl_FW_Version3";
            this.lbl_FW_Version3.Size = new System.Drawing.Size(187, 18);
            this.lbl_FW_Version3.TabIndex = 921;
            this.lbl_FW_Version3.Text = "version";
            this.lbl_FW_Version3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lbl_FW_Version4
            // 
            this.lbl_FW_Version4.Location = new System.Drawing.Point(543, 478);
            this.lbl_FW_Version4.Name = "lbl_FW_Version4";
            this.lbl_FW_Version4.Size = new System.Drawing.Size(187, 18);
            this.lbl_FW_Version4.TabIndex = 931;
            this.lbl_FW_Version4.Text = "version";
            this.lbl_FW_Version4.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lbl_FW_Version5
            // 
            this.lbl_FW_Version5.Location = new System.Drawing.Point(543, 496);
            this.lbl_FW_Version5.Name = "lbl_FW_Version5";
            this.lbl_FW_Version5.Size = new System.Drawing.Size(187, 18);
            this.lbl_FW_Version5.TabIndex = 941;
            this.lbl_FW_Version5.Text = "version";
            this.lbl_FW_Version5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // gbx_fileselect2
            // 
            this.gbx_fileselect2.Controls.Add(this.txtbx_file_read_result2);
            this.gbx_fileselect2.Controls.Add(this.label11);
            this.gbx_fileselect2.Controls.Add(this.txtbx_file_path2);
            this.gbx_fileselect2.Controls.Add(this.label12);
            this.gbx_fileselect2.Controls.Add(this.btn_file_select2);
            this.gbx_fileselect2.Controls.Add(this.chkbx_loop2);
            this.gbx_fileselect2.Location = new System.Drawing.Point(10, 85);
            this.gbx_fileselect2.Name = "gbx_fileselect2";
            this.gbx_fileselect2.Size = new System.Drawing.Size(728, 70);
            this.gbx_fileselect2.TabIndex = 200;
            this.gbx_fileselect2.TabStop = false;
            this.gbx_fileselect2.Tag = "1";
            this.gbx_fileselect2.Text = "制御基板No.2 ファイル指定";
            this.gbx_fileselect2.DragDrop += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragDrop);
            this.gbx_fileselect2.DragOver += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragOver);
            // 
            // txtbx_file_read_result2
            // 
            this.txtbx_file_read_result2.Location = new System.Drawing.Point(128, 41);
            this.txtbx_file_read_result2.Name = "txtbx_file_read_result2";
            this.txtbx_file_read_result2.ReadOnly = true;
            this.txtbx_file_read_result2.Size = new System.Drawing.Size(513, 19);
            this.txtbx_file_read_result2.TabIndex = 211;
            this.txtbx_file_read_result2.TabStop = false;
            this.txtbx_file_read_result2.Tag = "1";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(22, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 23);
            this.label11.TabIndex = 210;
            this.label11.Text = "読み込み結果";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_file_path2
            // 
            this.txtbx_file_path2.Location = new System.Drawing.Point(63, 17);
            this.txtbx_file_path2.Name = "txtbx_file_path2";
            this.txtbx_file_path2.ReadOnly = true;
            this.txtbx_file_path2.Size = new System.Drawing.Size(578, 19);
            this.txtbx_file_path2.TabIndex = 202;
            this.txtbx_file_path2.TabStop = false;
            this.txtbx_file_path2.Tag = "1";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(15, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 23);
            this.label12.TabIndex = 201;
            this.label12.Text = "File";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_file_select2
            // 
            this.btn_file_select2.Location = new System.Drawing.Point(643, 15);
            this.btn_file_select2.Name = "btn_file_select2";
            this.btn_file_select2.Size = new System.Drawing.Size(75, 23);
            this.btn_file_select2.TabIndex = 303;
            this.btn_file_select2.Tag = "1";
            this.btn_file_select2.Text = "選択";
            this.btn_file_select2.UseVisualStyleBackColor = true;
            this.btn_file_select2.Click += new System.EventHandler(this.btn_file_select_Click);
            // 
            // chkbx_loop2
            // 
            this.chkbx_loop2.AutoSize = true;
            this.chkbx_loop2.Location = new System.Drawing.Point(657, 44);
            this.chkbx_loop2.Name = "chkbx_loop2";
            this.chkbx_loop2.Size = new System.Drawing.Size(48, 16);
            this.chkbx_loop2.TabIndex = 212;
            this.chkbx_loop2.Tag = "1";
            this.chkbx_loop2.Text = "Loop";
            this.chkbx_loop2.UseVisualStyleBackColor = true;
            this.chkbx_loop2.CheckedChanged += new System.EventHandler(this.chkbx_loop_CheckedChanged);
            // 
            // gbx_fileselect3
            // 
            this.gbx_fileselect3.Controls.Add(this.txtbx_file_read_result3);
            this.gbx_fileselect3.Controls.Add(this.label13);
            this.gbx_fileselect3.Controls.Add(this.txtbx_file_path3);
            this.gbx_fileselect3.Controls.Add(this.label14);
            this.gbx_fileselect3.Controls.Add(this.btn_file_select3);
            this.gbx_fileselect3.Controls.Add(this.chkbx_loop3);
            this.gbx_fileselect3.Location = new System.Drawing.Point(10, 160);
            this.gbx_fileselect3.Name = "gbx_fileselect3";
            this.gbx_fileselect3.Size = new System.Drawing.Size(728, 70);
            this.gbx_fileselect3.TabIndex = 300;
            this.gbx_fileselect3.TabStop = false;
            this.gbx_fileselect3.Tag = "2";
            this.gbx_fileselect3.Text = "制御基板No.3 ファイル指定";
            this.gbx_fileselect3.DragDrop += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragDrop);
            this.gbx_fileselect3.DragOver += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragOver);
            // 
            // txtbx_file_read_result3
            // 
            this.txtbx_file_read_result3.Location = new System.Drawing.Point(128, 41);
            this.txtbx_file_read_result3.Name = "txtbx_file_read_result3";
            this.txtbx_file_read_result3.ReadOnly = true;
            this.txtbx_file_read_result3.Size = new System.Drawing.Size(513, 19);
            this.txtbx_file_read_result3.TabIndex = 311;
            this.txtbx_file_read_result3.TabStop = false;
            this.txtbx_file_read_result3.Tag = "2";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(22, 39);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 23);
            this.label13.TabIndex = 310;
            this.label13.Text = "読み込み結果";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_file_path3
            // 
            this.txtbx_file_path3.Location = new System.Drawing.Point(63, 17);
            this.txtbx_file_path3.Name = "txtbx_file_path3";
            this.txtbx_file_path3.ReadOnly = true;
            this.txtbx_file_path3.Size = new System.Drawing.Size(578, 19);
            this.txtbx_file_path3.TabIndex = 302;
            this.txtbx_file_path3.TabStop = false;
            this.txtbx_file_path3.Tag = "2";
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(15, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 23);
            this.label14.TabIndex = 301;
            this.label14.Text = "File";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_file_select3
            // 
            this.btn_file_select3.Location = new System.Drawing.Point(643, 15);
            this.btn_file_select3.Name = "btn_file_select3";
            this.btn_file_select3.Size = new System.Drawing.Size(75, 23);
            this.btn_file_select3.TabIndex = 303;
            this.btn_file_select3.Tag = "2";
            this.btn_file_select3.Text = "選択";
            this.btn_file_select3.UseVisualStyleBackColor = true;
            this.btn_file_select3.Click += new System.EventHandler(this.btn_file_select_Click);
            // 
            // chkbx_loop3
            // 
            this.chkbx_loop3.AutoSize = true;
            this.chkbx_loop3.Location = new System.Drawing.Point(657, 44);
            this.chkbx_loop3.Name = "chkbx_loop3";
            this.chkbx_loop3.Size = new System.Drawing.Size(48, 16);
            this.chkbx_loop3.TabIndex = 312;
            this.chkbx_loop3.Tag = "2";
            this.chkbx_loop3.Text = "Loop";
            this.chkbx_loop3.UseVisualStyleBackColor = true;
            this.chkbx_loop3.CheckedChanged += new System.EventHandler(this.chkbx_loop_CheckedChanged);
            // 
            // gbx_fileselect4
            // 
            this.gbx_fileselect4.Controls.Add(this.txtbx_file_read_result4);
            this.gbx_fileselect4.Controls.Add(this.label15);
            this.gbx_fileselect4.Controls.Add(this.txtbx_file_path4);
            this.gbx_fileselect4.Controls.Add(this.label16);
            this.gbx_fileselect4.Controls.Add(this.btn_file_select4);
            this.gbx_fileselect4.Controls.Add(this.chkbx_loop4);
            this.gbx_fileselect4.Location = new System.Drawing.Point(10, 235);
            this.gbx_fileselect4.Name = "gbx_fileselect4";
            this.gbx_fileselect4.Size = new System.Drawing.Size(728, 70);
            this.gbx_fileselect4.TabIndex = 400;
            this.gbx_fileselect4.TabStop = false;
            this.gbx_fileselect4.Tag = "3";
            this.gbx_fileselect4.Text = "制御基板No.4 ファイル指定";
            this.gbx_fileselect4.DragDrop += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragDrop);
            this.gbx_fileselect4.DragOver += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragOver);
            // 
            // txtbx_file_read_result4
            // 
            this.txtbx_file_read_result4.Location = new System.Drawing.Point(128, 41);
            this.txtbx_file_read_result4.Name = "txtbx_file_read_result4";
            this.txtbx_file_read_result4.ReadOnly = true;
            this.txtbx_file_read_result4.Size = new System.Drawing.Size(513, 19);
            this.txtbx_file_read_result4.TabIndex = 411;
            this.txtbx_file_read_result4.TabStop = false;
            this.txtbx_file_read_result4.Tag = "3";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(22, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 23);
            this.label15.TabIndex = 410;
            this.label15.Text = "読み込み結果";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_file_path4
            // 
            this.txtbx_file_path4.Location = new System.Drawing.Point(63, 17);
            this.txtbx_file_path4.Name = "txtbx_file_path4";
            this.txtbx_file_path4.ReadOnly = true;
            this.txtbx_file_path4.Size = new System.Drawing.Size(578, 19);
            this.txtbx_file_path4.TabIndex = 402;
            this.txtbx_file_path4.TabStop = false;
            this.txtbx_file_path4.Tag = "3";
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(15, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 23);
            this.label16.TabIndex = 401;
            this.label16.Text = "File";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_file_select4
            // 
            this.btn_file_select4.Location = new System.Drawing.Point(643, 15);
            this.btn_file_select4.Name = "btn_file_select4";
            this.btn_file_select4.Size = new System.Drawing.Size(75, 23);
            this.btn_file_select4.TabIndex = 403;
            this.btn_file_select4.Tag = "3";
            this.btn_file_select4.Text = "選択";
            this.btn_file_select4.UseVisualStyleBackColor = true;
            this.btn_file_select4.Click += new System.EventHandler(this.btn_file_select_Click);
            // 
            // chkbx_loop4
            // 
            this.chkbx_loop4.AutoSize = true;
            this.chkbx_loop4.Location = new System.Drawing.Point(657, 44);
            this.chkbx_loop4.Name = "chkbx_loop4";
            this.chkbx_loop4.Size = new System.Drawing.Size(48, 16);
            this.chkbx_loop4.TabIndex = 412;
            this.chkbx_loop4.Tag = "3";
            this.chkbx_loop4.Text = "Loop";
            this.chkbx_loop4.UseVisualStyleBackColor = true;
            this.chkbx_loop4.CheckedChanged += new System.EventHandler(this.chkbx_loop_CheckedChanged);
            // 
            // gbx_fileselect5
            // 
            this.gbx_fileselect5.Controls.Add(this.txtbx_file_read_result5);
            this.gbx_fileselect5.Controls.Add(this.label17);
            this.gbx_fileselect5.Controls.Add(this.txtbx_file_path5);
            this.gbx_fileselect5.Controls.Add(this.label18);
            this.gbx_fileselect5.Controls.Add(this.btn_file_select5);
            this.gbx_fileselect5.Controls.Add(this.chkbx_loop5);
            this.gbx_fileselect5.Location = new System.Drawing.Point(10, 310);
            this.gbx_fileselect5.Name = "gbx_fileselect5";
            this.gbx_fileselect5.Size = new System.Drawing.Size(728, 70);
            this.gbx_fileselect5.TabIndex = 500;
            this.gbx_fileselect5.TabStop = false;
            this.gbx_fileselect5.Tag = "4";
            this.gbx_fileselect5.Text = "制御基板No.5 ファイル指定";
            this.gbx_fileselect5.DragDrop += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragDrop);
            this.gbx_fileselect5.DragOver += new System.Windows.Forms.DragEventHandler(this.gbx_fileselect_DragOver);
            // 
            // txtbx_file_read_result5
            // 
            this.txtbx_file_read_result5.Location = new System.Drawing.Point(128, 41);
            this.txtbx_file_read_result5.Name = "txtbx_file_read_result5";
            this.txtbx_file_read_result5.ReadOnly = true;
            this.txtbx_file_read_result5.Size = new System.Drawing.Size(513, 19);
            this.txtbx_file_read_result5.TabIndex = 511;
            this.txtbx_file_read_result5.TabStop = false;
            this.txtbx_file_read_result5.Tag = "4";
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(22, 39);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 23);
            this.label17.TabIndex = 510;
            this.label17.Text = "読み込み結果";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_file_path5
            // 
            this.txtbx_file_path5.Location = new System.Drawing.Point(63, 17);
            this.txtbx_file_path5.Name = "txtbx_file_path5";
            this.txtbx_file_path5.ReadOnly = true;
            this.txtbx_file_path5.Size = new System.Drawing.Size(578, 19);
            this.txtbx_file_path5.TabIndex = 502;
            this.txtbx_file_path5.TabStop = false;
            this.txtbx_file_path5.Tag = "4";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(15, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 23);
            this.label18.TabIndex = 501;
            this.label18.Text = "File";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_file_select5
            // 
            this.btn_file_select5.Location = new System.Drawing.Point(643, 15);
            this.btn_file_select5.Name = "btn_file_select5";
            this.btn_file_select5.Size = new System.Drawing.Size(75, 23);
            this.btn_file_select5.TabIndex = 503;
            this.btn_file_select5.Tag = "4";
            this.btn_file_select5.Text = "選択";
            this.btn_file_select5.UseVisualStyleBackColor = true;
            this.btn_file_select5.Click += new System.EventHandler(this.btn_file_select_Click);
            // 
            // chkbx_loop5
            // 
            this.chkbx_loop5.AutoSize = true;
            this.chkbx_loop5.Location = new System.Drawing.Point(657, 44);
            this.chkbx_loop5.Name = "chkbx_loop5";
            this.chkbx_loop5.Size = new System.Drawing.Size(48, 16);
            this.chkbx_loop5.TabIndex = 512;
            this.chkbx_loop5.Tag = "4";
            this.chkbx_loop5.Text = "Loop";
            this.chkbx_loop5.UseVisualStyleBackColor = true;
            this.chkbx_loop5.CheckedChanged += new System.EventHandler(this.chkbx_loop_CheckedChanged);
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(749, 526);
            this.Controls.Add(this.gbx_fileselect5);
            this.Controls.Add(this.gbx_fileselect4);
            this.Controls.Add(this.gbx_fileselect3);
            this.Controls.Add(this.gbx_fileselect2);
            this.Controls.Add(this.lbl_FW_Version5);
            this.Controls.Add(this.lbl_FW_Version4);
            this.Controls.Add(this.lbl_FW_Version3);
            this.Controls.Add(this.lbl_FW_Version2);
            this.Controls.Add(this.lbl_Status5);
            this.Controls.Add(this.lbl_Status4);
            this.Controls.Add(this.lbl_Status3);
            this.Controls.Add(this.lbl_Status2);
            this.Controls.Add(this.lbl_Status1);
            this.Controls.Add(this.lbl_FW_Version1);
            this.Controls.Add(this.btn_LED_Control_Start_Stop);
            this.Controls.Add(this.gbx_fileselect1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "USB LED Controller Configration Tool";
            this.gbx_fileselect1.ResumeLayout(false);
            this.gbx_fileselect1.PerformLayout();
            this.gbx_fileselect2.ResumeLayout(false);
            this.gbx_fileselect2.PerformLayout();
            this.gbx_fileselect3.ResumeLayout(false);
            this.gbx_fileselect3.PerformLayout();
            this.gbx_fileselect4.ResumeLayout(false);
            this.gbx_fileselect4.PerformLayout();
            this.gbx_fileselect5.ResumeLayout(false);
            this.gbx_fileselect5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.GroupBox gbx_fileselect1;
        private System.Windows.Forms.TextBox txtbx_file_read_result1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbx_file_path1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_file_select1;
        private System.Windows.Forms.Button btn_LED_Control_Start_Stop;
        private System.Windows.Forms.Label lbl_FW_Version1;
        private System.Windows.Forms.Label lbl_Status1;
        private System.Windows.Forms.Timer FormUpdateTimer_Tick;
        private System.Windows.Forms.CheckBox chkbx_loop1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label lbl_Status2;
        private System.Windows.Forms.Label lbl_Status3;
        private System.Windows.Forms.Label lbl_Status4;
        private System.Windows.Forms.Label lbl_Status5;
        private System.Windows.Forms.Label lbl_FW_Version2;
        private System.Windows.Forms.Label lbl_FW_Version3;
        private System.Windows.Forms.Label lbl_FW_Version4;
        private System.Windows.Forms.Label lbl_FW_Version5;
        private System.Windows.Forms.GroupBox gbx_fileselect2;
        private System.Windows.Forms.TextBox txtbx_file_read_result2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbx_file_path2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_file_select2;
        private System.Windows.Forms.CheckBox chkbx_loop2;
        private System.Windows.Forms.GroupBox gbx_fileselect3;
        private System.Windows.Forms.TextBox txtbx_file_read_result3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtbx_file_path3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btn_file_select3;
        private System.Windows.Forms.CheckBox chkbx_loop3;
        private System.Windows.Forms.GroupBox gbx_fileselect4;
        private System.Windows.Forms.TextBox txtbx_file_read_result4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtbx_file_path4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btn_file_select4;
        private System.Windows.Forms.CheckBox chkbx_loop4;
        private System.Windows.Forms.GroupBox gbx_fileselect5;
        private System.Windows.Forms.TextBox txtbx_file_read_result5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtbx_file_path5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btn_file_select5;
        private System.Windows.Forms.CheckBox chkbx_loop5;
    }
}

