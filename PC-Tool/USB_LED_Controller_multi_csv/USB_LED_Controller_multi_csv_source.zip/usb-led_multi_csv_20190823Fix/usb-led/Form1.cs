﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Threading;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        internal const int USB_CONNECT_NUM = 5;
        internal string[] DEF_VID_PID = new string[USB_CONNECT_NUM] { "Vid_22EA&Pid_005D", "Vid_22EA&Pid_0062", "Vid_22EA&Pid_0063", "Vid_22EA&Pid_0064", "Vid_22EA&Pid_0065" };

        //Constant definitions from setupapi.h, which we aren't allowed to include directly since this is C#
        internal const uint DIGCF_PRESENT = 0x02;
        internal const uint DIGCF_DEVICEINTERFACE = 0x10;
        //Constants for CreateFile() and other file I/O functions
        internal const short FILE_ATTRIBUTE_NORMAL = 0x80;
        internal const short INVALID_HANDLE_VALUE = -1;
        internal const uint GENERIC_READ = 0x80000000;
        internal const uint GENERIC_WRITE = 0x40000000;
        internal const uint CREATE_NEW = 1;
        internal const uint CREATE_ALWAYS = 2;
        internal const uint OPEN_EXISTING = 3;
        internal const uint FILE_SHARE_READ = 0x00000001;
        internal const uint FILE_SHARE_WRITE = 0x00000002;
        //Constant definitions for certain WM_DEVICECHANGE messages
        internal const uint WM_DEVICECHANGE = 0x0219;
        internal const uint DBT_DEVICEARRIVAL = 0x8000;
        internal const uint DBT_DEVICEREMOVEPENDING = 0x8003;
        internal const uint DBT_DEVICEREMOVECOMPLETE = 0x8004;
        internal const uint DBT_CONFIGCHANGED = 0x0018;
        //Other constant definitions
        internal const uint DBT_DEVTYP_DEVICEINTERFACE = 0x05;
        internal const uint DEVICE_NOTIFY_WINDOW_HANDLE = 0x00;
        internal const uint ERROR_SUCCESS = 0x00;
        internal const uint ERROR_NO_MORE_ITEMS = 0x00000103;
        internal const uint SPDRP_HARDWAREID = 0x00000001;

        //Various structure definitions for structures that this code will be using
        internal struct SP_DEVICE_INTERFACE_DATA
        {
            internal uint cbSize;               //DWORD
            internal Guid InterfaceClassGuid;   //GUID
            internal uint Flags;                //DWORD
            internal uint Reserved;             //ULONG_PTR MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct SP_DEVICE_INTERFACE_DETAIL_DATA
        {
            internal uint cbSize;               //DWORD
            internal char[] DevicePath;         //TCHAR array of any size
        }

        internal struct SP_DEVINFO_DATA
        {
            internal uint cbSize;       //DWORD
            internal Guid ClassGuid;    //GUID
            internal uint DevInst;      //DWORD
            internal uint Reserved;     //ULONG_PTR  MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct DEV_BROADCAST_DEVICEINTERFACE
        {
            internal uint dbcc_size;            //DWORD
            internal uint dbcc_devicetype;      //DWORD
            internal uint dbcc_reserved;        //DWORD
            internal Guid dbcc_classguid;       //GUID
            internal char[] dbcc_name;          //TCHAR array
        }

        //DLL Imports.  Need these to access various C style unmanaged functions contained in their respective DLL files.
        //--------------------------------------------------------------------------------------------------------------
        //Returns a HDEVINFO type for a device information set.  We will need the 
        //HDEVINFO as in input parameter for calling many of the other SetupDixxx() functions.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr SetupDiGetClassDevs(
            ref Guid ClassGuid,     //LPGUID    Input: Need to supply the class GUID. 
            IntPtr Enumerator,      //PCTSTR    Input: Use NULL here, not important for our purposes
            IntPtr hwndParent,      //HWND      Input: Use NULL here, not important for our purposes
            uint Flags);            //DWORD     Input: Flags describing what kind of filtering to use.

        //Gives us "PSP_DEVICE_INTERFACE_DATA" which contains the Interface specific GUID (different
        //from class GUID).  We need the interface GUID to get the device path.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInterfaces(
            IntPtr DeviceInfoSet,           //Input: Give it the HDEVINFO we got from SetupDiGetClassDevs()
            IntPtr DeviceInfoData,          //Input (optional)
            ref Guid InterfaceClassGuid,    //Input 
            uint MemberIndex,               //Input: "Index" of the device you are interested in getting the path for.
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData);    //Output: This function fills in an "SP_DEVICE_INTERFACE_DATA" structure.

        //SetupDiDestroyDeviceInfoList() frees up memory by destroying a DeviceInfoList
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiDestroyDeviceInfoList(
            IntPtr DeviceInfoSet);          //Input: Give it a handle to a device info list to deallocate from RAM.

        //SetupDiEnumDeviceInfo() fills in an "SP_DEVINFO_DATA" structure, which we need for SetupDiGetDeviceRegistryProperty()
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInfo(
            IntPtr DeviceInfoSet,
            uint MemberIndex,
            ref SP_DEVINFO_DATA DeviceInterfaceData);

        //SetupDiGetDeviceRegistryProperty() gives us the hardware ID, which we use to check to see if it has matching VID/PID
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceRegistryProperty(
            IntPtr DeviceInfoSet,
            ref SP_DEVINFO_DATA DeviceInfoData,
            uint Property,
            ref uint PropertyRegDataType,
            IntPtr PropertyBuffer,
            uint PropertyBufferSize,
            ref uint RequiredSize);

        //SetupDiGetDeviceInterfaceDetail() gives us a device path, which is needed before CreateFile() can be used.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,                    //Input: Pointer to an structure which defines the device interface.  
            IntPtr DeviceInterfaceDetailData,      //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will receive the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            ref uint RequiredSize,                  //Output (optional): The number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Overload for SetupDiGetDeviceInterfaceDetail().  Need this one since we can't pass NULL pointers directly in C#.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,               //Input: Pointer to an structure which defines the device interface.  
            IntPtr DeviceInterfaceDetailData,       //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will contain the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            IntPtr RequiredSize,                    //Output (optional): Pointer to a DWORD to tell you the number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Need this function for receiving all of the WM_DEVICECHANGE messages.  See MSDN documentation for
        //description of what this function does/how to use it. Note: name is remapped "RegisterDeviceNotificationUM" to
        //avoid possible build error conflicts.
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr RegisterDeviceNotification(
            IntPtr hRecipient,
            IntPtr NotificationFilter,
            uint Flags);

        //Takes in a device path and opens a handle to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern SafeFileHandle CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode,
            IntPtr lpSecurityAttributes,
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        //Uses a handle (created with CreateFile()), and lets us write USB data to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            uint nNumberOfBytesToWrite,
            ref uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        //Uses a handle (created with CreateFile()), and lets us read USB data from the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool ReadFile(
            SafeFileHandle hFile,
            IntPtr lpBuffer,
            uint nNumberOfBytesToRead,
            ref uint lpNumberOfBytesRead,
            IntPtr lpOverlapped);



        //--------------- Global Varibles Section ------------------
        //USB related variables that need to have wide scope.
        bool[] AttachedState = new bool[USB_CONNECT_NUM] { false, false, false, false, false };						//Need to keep track of the USB device attachment status for proper plug and play operation.
        bool[] AttachedButBroken = new bool[USB_CONNECT_NUM] { false, false, false, false, false };
        SafeFileHandle[] WriteHandleToUSBDevice = new SafeFileHandle[USB_CONNECT_NUM] { null, null, null, null, null };
        SafeFileHandle[] ReadHandleToUSBDevice = new SafeFileHandle[USB_CONNECT_NUM] { null, null, null, null, null };
        String[] DevicePath = new String[USB_CONNECT_NUM] { null, null, null, null, null };   //Need the find the proper device path before you can open file handles.

        bool[] ConnectFirstTime = new bool[USB_CONNECT_NUM] { true, true, true, true, true };
        bool[] UnConnectFirstTime = new bool[USB_CONNECT_NUM] { true, true, true, true, true };
        bool[] VersionReadReq = new bool[USB_CONNECT_NUM] { true, true, true, true, true };
        bool[] VersionReadComp = new bool[USB_CONNECT_NUM] { false, false, false, false, false };
        byte[,] version_buff = new byte[USB_CONNECT_NUM, 64];

        bool[] b_LED_Ctrl_flag = new bool[Constants.USB_CONNECT_NUM_MAX] { false, false, false, false, false };
        bool[] b_file_read_comp = new bool[Constants.USB_CONNECT_NUM_MAX] { false, false, false, false, false };
        DateTime[] dt_ctrl_start_datetime = new DateTime[Constants.USB_CONNECT_NUM_MAX];
        DateTime[] dt_ctrl_next_datetime = new DateTime[Constants.USB_CONNECT_NUM_MAX];
        int[] ctrl_data_idx = new int[Constants.USB_CONNECT_NUM_MAX];
        bool[] b_loop_flag = new bool[Constants.USB_CONNECT_NUM_MAX] { false, false, false, false, false };
        bool[] b_led_off_set_req = new bool[Constants.USB_CONNECT_NUM_MAX] { false, false, false, false, false };

        double[,] read_data_time = new double[Constants.USB_CONNECT_NUM_MAX,Constants.READ_DATA_MAX];
        byte[, ,] read_data_led = new byte[Constants.USB_CONNECT_NUM_MAX, Constants.READ_DATA_MAX, Constants.LED_NUM];
        int[] read_data_count = new int[Constants.USB_CONNECT_NUM_MAX];

        GroupBox[] my_gbx_file_select;
        TextBox[] my_txtbx_file_path;
        Button[] my_btn_file_select;
        TextBox[] my_txtbx_read_result;
        CheckBox[] my_chkbx_loop;
        Label[] my_lbl_status;
        Label[] my_lbl_fw_version;

        int[,] Debug_Array = new int[USB_CONNECT_NUM, 16];    //DEBUG
        int[,] Debug_Array2 = new int[USB_CONNECT_NUM, 16];    //DEBUG


        //Globally Unique Identifier (GUID) for HID class devices.  Windows uses GUIDs to identify things.
        Guid InterfaceClassGuid = new Guid(0x4d1e55b2, 0xf16f, 0x11cf, 0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30);
        //--------------- End of Global Varibles ------------------


        public unsafe Form1()
        {
            InitializeComponent();
            
             //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
			//Additional constructor code

            //自分自身のバージョン情報を取得する
            System.Diagnostics.FileVersionInfo fver = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly().Location);
#if DEBUG
            // デバッグ
            this.Text = "デバッグ版 " + this.Text + fver.FileVersion;
#else
            // リリース
            this.Size = new System.Drawing.Size(755, 555);
            this.Text += fver.FileVersion;
#endif

            my_gbx_file_select = new GroupBox[] { gbx_fileselect1, gbx_fileselect2, gbx_fileselect3, gbx_fileselect4, gbx_fileselect5 };
            my_txtbx_file_path = new TextBox[] { txtbx_file_path1, txtbx_file_path2, txtbx_file_path3, txtbx_file_path4, txtbx_file_path5 };
            my_btn_file_select = new Button[] { btn_file_select1, btn_file_select2, btn_file_select3, btn_file_select4, btn_file_select5 };
            my_txtbx_read_result = new TextBox[] { txtbx_file_read_result1, txtbx_file_read_result2, txtbx_file_read_result3, txtbx_file_read_result4, txtbx_file_read_result5 };
            my_chkbx_loop = new CheckBox[] { chkbx_loop1, chkbx_loop2, chkbx_loop3, chkbx_loop4, chkbx_loop5 };
            my_lbl_status = new Label[] { lbl_Status1, lbl_Status2, lbl_Status3, lbl_Status4, lbl_Status5 };
            my_lbl_fw_version = new Label[] { lbl_FW_Version1, lbl_FW_Version2, lbl_FW_Version3, lbl_FW_Version4, lbl_FW_Version5 };

            for (int fi = 0; fi < my_gbx_file_select.Length; fi++ )
            {
                my_gbx_file_select[fi].AllowDrop = true;
            }

            //Initialize tool tips, to provide pop up help when the mouse cursor is moved over objects on the form.

            //Register for WM_DEVICECHANGE notifications.  This code uses these messages to detect plug and play connection/disconnection events for USB devices
            DEV_BROADCAST_DEVICEINTERFACE DeviceBroadcastHeader = new DEV_BROADCAST_DEVICEINTERFACE();
            DeviceBroadcastHeader.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
            DeviceBroadcastHeader.dbcc_size = (uint)Marshal.SizeOf(DeviceBroadcastHeader);
            DeviceBroadcastHeader.dbcc_reserved = 0;	//Reserved says not to use...
            DeviceBroadcastHeader.dbcc_classguid = InterfaceClassGuid;

            //Need to get the address of the DeviceBroadcastHeader to call RegisterDeviceNotification(), but
            //can't use "&DeviceBroadcastHeader".  Instead, using a roundabout means to get the address by 
            //making a duplicate copy using Marshal.StructureToPtr().
            IntPtr pDeviceBroadcastHeader = IntPtr.Zero;  //Make a pointer.
            pDeviceBroadcastHeader = Marshal.AllocHGlobal(Marshal.SizeOf(DeviceBroadcastHeader)); //allocate memory for a new DEV_BROADCAST_DEVICEINTERFACE structure, and return the address 
            Marshal.StructureToPtr(DeviceBroadcastHeader, pDeviceBroadcastHeader, false);  //Copies the DeviceBroadcastHeader structure into the memory already allocated at DeviceBroadcastHeaderWithPointer
            RegisterDeviceNotification(this.Handle, pDeviceBroadcastHeader, DEVICE_NOTIFY_WINDOW_HANDLE);
 

			//Now make an initial attempt to find the USB device, if it was already connected to the PC and enumerated prior to launching the application.
			//If it is connected and present, we should open read and write handles to the device so we can communicate with it later.
			//If it was not connected, we will have to wait until the user plugs the device in, and the WM_DEVICECHANGE callback function can process
			//the message and again search for the device.
            for (int fi = 0; fi < USB_CONNECT_NUM; fi++)
            {
                if (CheckIfPresentAndGetUSBDevicePath(fi, DEF_VID_PID[fi]))	//Check and make sure at least one device with matching VID/PID is attached
                {
                    uint ErrorStatusWrite;
                    uint ErrorStatusRead;


                    //We now have the proper device path, and we can finally open read and write handles to the device.
                    WriteHandleToUSBDevice[fi] = CreateFile(DevicePath[fi], GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                    ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                    ReadHandleToUSBDevice[fi] = CreateFile(DevicePath[fi], GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                    ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

                    if ((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
                    {
                        AttachedState[fi] = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
                        AttachedButBroken[fi] = false;
                        //StatusBox_lbl.Text = "デバイス検出済";
                    }
                    else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
                    {
                        AttachedState[fi] = false;		//Let the rest of this application known not to read/write to the device.
                        AttachedButBroken[fi] = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
                        if (ErrorStatusWrite == ERROR_SUCCESS)
                            WriteHandleToUSBDevice[fi].Close();
                        if (ErrorStatusRead == ERROR_SUCCESS)
                            ReadHandleToUSBDevice[fi].Close();
                    }
                }
                else	//Device must not be connected (or not programmed with correct firmware)
                {
                    AttachedState[fi] = false;
                    AttachedButBroken[fi] = false;
                }

                if (AttachedState[fi] == true)
                {
                    my_lbl_status[fi].Text = string.Format(Constants.USB_CONNECT_MSG, fi + 1);
                }
                else
                {
                    my_lbl_status[fi].Text = string.Format(Constants.USB_DISCONNECT_MSG, fi + 1);
                }
            }
            
			ReadWriteThread.RunWorkerAsync();	//Recommend performing USB read/write operations in a separate thread.  Otherwise,
												//the Read/Write operations are effectively blocking functions and can lock up the
												//user interface if the I/O operations take a long time to complete.

            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //FUNCTION:	CheckIfPresentAndGetUSBDevicePath()
        //PURPOSE:	Check if a USB device is currently plugged in with a matching VID and PID
        //INPUT:	Uses globally declared String DevicePath, globally declared GUID, and the MY_DEVICE_ID constant.
        //OUTPUT:	Returns BOOL.  TRUE when device with matching VID/PID found.  FALSE if device with VID/PID could not be found.
        //			When returns TRUE, the globally accessable "DetailedInterfaceDataStructure" will contain the device path
        //			to the USB device with the matching VID/PID.

        bool CheckIfPresentAndGetUSBDevicePath(int p_idx, string p_VID_PID)
        {
            /* 
            Before we can "connect" our application to our USB embedded device, we must first find the device.
            A USB bus can have many devices simultaneously connected, so somehow we have to find our device only.
            This is done with the Vendor ID (VID) and Product ID (PID).  Each USB product line should have
            a unique combination of VID and PID.  

            Microsoft has created a number of functions which are useful for finding plug and play devices.  Documentation
            for each function used can be found in the MSDN library.  We will be using the following functions (unmanaged C functions):

            SetupDiGetClassDevs()					//provided by setupapi.dll, which comes with Windows
            SetupDiEnumDeviceInterfaces()			//provided by setupapi.dll, which comes with Windows
            GetLastError()							//provided by kernel32.dll, which comes with Windows
            SetupDiDestroyDeviceInfoList()			//provided by setupapi.dll, which comes with Windows
            SetupDiGetDeviceInterfaceDetail()		//provided by setupapi.dll, which comes with Windows
            SetupDiGetDeviceRegistryProperty()		//provided by setupapi.dll, which comes with Windows
            CreateFile()							//provided by kernel32.dll, which comes with Windows

            In order to call these unmanaged functions, the Marshal class is very useful.
             
            We will also be using the following unusual data types and structures.  Documentation can also be found in
            the MSDN library:

            PSP_DEVICE_INTERFACE_DATA
            PSP_DEVICE_INTERFACE_DETAIL_DATA
            SP_DEVINFO_DATA
            HDEVINFO
            HANDLE
            GUID

            The ultimate objective of the following code is to get the device path, which will be used elsewhere for getting
            read and write handles to the USB device.  Once the read/write handles are opened, only then can this
            PC application begin reading/writing to the USB device using the WriteFile() and ReadFile() functions.

            Getting the device path is a multi-step round about process, which requires calling several of the
            SetupDixxx() functions provided by setupapi.dll.
            */

            try
            {
                IntPtr DeviceInfoTable = IntPtr.Zero;
                SP_DEVICE_INTERFACE_DATA InterfaceDataStructure = new SP_DEVICE_INTERFACE_DATA();
                SP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA();
                SP_DEVINFO_DATA DevInfoData = new SP_DEVINFO_DATA();

                uint InterfaceIndex = 0;
                uint dwRegType = 0;
                uint dwRegSize = 0;
                uint dwRegSize2 = 0;
                uint StructureSize = 0;
                IntPtr PropertyValueBuffer = IntPtr.Zero;
                bool MatchFound = false;
                //bool MatchFound2 = false;
                uint ErrorStatus;
                uint LoopCounter = 0;

                //Use the formatting: "Vid_xxxx&Pid_xxxx" where xxxx is a 16-bit hexadecimal number.
                //Make sure the value appearing in the parathesis matches the USB device descriptor
                //of the device that this aplication is intending to find.
                String DeviceIDToFind = p_VID_PID;
                //String DeviceIDToFind2 = "Mi_03";


                //First populate a list of plugged in devices (by specifying "DIGCF_PRESENT"), which are of the specified class GUID. 
                DeviceInfoTable = SetupDiGetClassDevs(ref InterfaceClassGuid, IntPtr.Zero, IntPtr.Zero, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

                if (DeviceInfoTable != IntPtr.Zero)
                {
                    //Now look through the list we just populated.  We are trying to see if any of them match our device. 
                    while (true)
                    {
                        InterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(InterfaceDataStructure);
                        if (SetupDiEnumDeviceInterfaces(DeviceInfoTable, IntPtr.Zero, ref InterfaceClassGuid, InterfaceIndex, ref InterfaceDataStructure))
                        {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
                            if (ErrorStatus == ERROR_NO_MORE_ITEMS)	//Did we reach the end of the list of matching devices in the DeviceInfoTable?
                            {	//Cound not find the device.  Must not have been attached.
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
                                return false;
                            }
                        }
                        else	//Else some other kind of unknown error ocurred...
                        {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
                            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
                            return false;
                        }

                        //Now retrieve the hardware ID from the registry.  The hardware ID contains the VID and PID, which we will then 
                        //check to see if it is the correct device or not.

                        //Initialize an appropriate SP_DEVINFO_DATA structure.  We need this structure for SetupDiGetDeviceRegistryProperty().
                        DevInfoData.cbSize = (uint)Marshal.SizeOf(DevInfoData);
                        SetupDiEnumDeviceInfo(DeviceInfoTable, InterfaceIndex, ref DevInfoData);

                        //First query for the size of the hardware ID, so we can know how big a buffer to allocate for the data.
                        SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, IntPtr.Zero, 0, ref dwRegSize);

                        //Allocate a buffer for the hardware ID.
                        //Should normally work, but could throw exception "OutOfMemoryException" if not enough resources available.
                        PropertyValueBuffer = Marshal.AllocHGlobal((int)dwRegSize);

                        //Retrieve the hardware IDs for the current device we are looking at.  PropertyValueBuffer gets filled with a 
                        //REG_MULTI_SZ (array of null terminated strings).  To find a device, we only care about the very first string in the
                        //buffer, which will be the "device ID".  The device ID is a string which contains the VID and PID, in the example 
                        //format "Vid_04d8&Pid_003f".
                        SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, PropertyValueBuffer, dwRegSize, ref dwRegSize2);

                        //Now check if the first string in the hardware ID matches the device ID of the USB device we are trying to find.
                        String DeviceIDFromRegistry = Marshal.PtrToStringUni(PropertyValueBuffer); //Make a new string, fill it with the contents from the PropertyValueBuffer

                        Marshal.FreeHGlobal(PropertyValueBuffer);		//No longer need the PropertyValueBuffer, free the memory to prevent potential memory leaks

                        //Convert both strings to lower case.  This makes the code more robust/portable accross OS Versions
                        DeviceIDFromRegistry = DeviceIDFromRegistry.ToLowerInvariant();
                        DeviceIDToFind = DeviceIDToFind.ToLowerInvariant();
                        //DeviceIDToFind2 = DeviceIDToFind2.ToLowerInvariant();
                        //Now check if the hardware ID we are looking at contains the correct VID/PID
                        MatchFound = DeviceIDFromRegistry.Contains(DeviceIDToFind);
                        //MatchFound2 = DeviceIDFromRegistry.Contains(DeviceIDToFind2);
                        //if (MatchFound == true && MatchFound2 == true)
                        if (MatchFound == true)
                        {
                            //Device must have been found.  In order to open I/O file handle(s), we will need the actual device path first.
                            //We can get the path by calling SetupDiGetDeviceInterfaceDetail(), however, we have to call this function twice:  The first
                            //time to get the size of the required structure/buffer to hold the detailed interface data, then a second time to actually 
                            //get the structure (after we have allocated enough memory for the structure.)
                            DetailedInterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(DetailedInterfaceDataStructure);
                            //First call populates "StructureSize" with the correct value
                            SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, IntPtr.Zero, 0, ref StructureSize, IntPtr.Zero);
                            //Need to call SetupDiGetDeviceInterfaceDetail() again, this time specifying a pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA buffer with the correct size of RAM allocated.
                            //First need to allocate the unmanaged buffer and get a pointer to it.
                            IntPtr pUnmanagedDetailedInterfaceDataStructure = IntPtr.Zero;  //Declare a pointer.
                            pUnmanagedDetailedInterfaceDataStructure = Marshal.AllocHGlobal((int)StructureSize);    //Reserve some unmanaged memory for the structure.
                            DetailedInterfaceDataStructure.cbSize = 6; //Initialize the cbSize parameter (4 bytes for DWORD + 2 bytes for unicode null terminator)
                            Marshal.StructureToPtr(DetailedInterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, false); //Copy managed structure contents into the unmanaged memory buffer.

                            //Now call SetupDiGetDeviceInterfaceDetail() a second time to receive the device path in the structure at pUnmanagedDetailedInterfaceDataStructure.
                            if (SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, StructureSize, IntPtr.Zero, IntPtr.Zero))
                            {
                                //Need to extract the path information from the unmanaged "structure".  The path starts at (pUnmanagedDetailedInterfaceDataStructure + sizeof(DWORD)).
                                IntPtr pToDevicePath = new IntPtr((uint)pUnmanagedDetailedInterfaceDataStructure.ToInt32() + 4);  //Add 4 to the pointer (to get the pointer to point to the path, instead of the DWORD cbSize parameter)
                                DevicePath[p_idx] = Marshal.PtrToStringUni(pToDevicePath); //Now copy the path information into the globally defined DevicePath String.

                                //We now have the proper device path, and we can finally use the path to open I/O handle(s) to the device.
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return true;    //Returning the device path in the global DevicePath String
                            }
                            else //Some unknown failure occurred
                            {
                                uint ErrorCode = (uint)Marshal.GetLastWin32Error();
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return false;
                            }
                        }

                        InterfaceIndex++;
                        //Keep looping until we either find a device with matching VID and PID, or until we run out of devices to check.
                        //However, just in case some unexpected error occurs, keep track of the number of loops executed.
                        //If the number of loops exceeds a very large number, exit anyway, to prevent inadvertent infinite looping.
                        LoopCounter++;
                        if (LoopCounter == 10000000)	//Surely there aren't more than 10 million devices attached to any forseeable PC...
                        {
                            return false;
                        }
                    }//end of while(true)
                }
                return false;
            }//end of try
            catch
            {
                //Something went wrong if PC gets here.  Maybe a Marshal.AllocHGlobal() failed due to insufficient resources or something.
                return false;
            }
        }
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        //This is a callback function that gets called when a Windows message is received by the form.
        //We will receive various different types of messages, but the ones we really want to use are the WM_DEVICECHANGE messages.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_DEVICECHANGE)
            {
                if (((int)m.WParam == DBT_DEVICEARRIVAL) || ((int)m.WParam == DBT_DEVICEREMOVEPENDING) || ((int)m.WParam == DBT_DEVICEREMOVECOMPLETE) || ((int)m.WParam == DBT_CONFIGCHANGED))
                {
                    //WM_DEVICECHANGE messages by themselves are quite generic, and can be caused by a number of different
                    //sources, not just your USB hardware device.  Therefore, must check to find out if any changes relavant
                    //to your device (with known VID/PID) took place before doing any kind of opening or closing of handles/endpoints.
                    //(the message could have been totally unrelated to your application/USB device)

                    for (int fi = 0; fi < USB_CONNECT_NUM; fi++)
                    {
                        if (CheckIfPresentAndGetUSBDevicePath(fi, DEF_VID_PID[fi]))	//Check and make sure at least one device with matching VID/PID is attached
                        {
                            //If executes to here, this means the device is currently attached and was found.
                            //This code needs to decide however what to do, based on whether or not the device was previously known to be
                            //attached or not.
                            if ((AttachedState[fi] == false) || (AttachedButBroken[fi] == true))	//Check the previous attachment state
                            {
                                uint ErrorStatusWrite;
                                uint ErrorStatusRead;

                                //We obtained the proper device path (from CheckIfPresentAndGetUSBDevicePath() function call), and it
                                //is now possible to open read and write handles to the device.
                                WriteHandleToUSBDevice[fi] = CreateFile(DevicePath[fi], GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                                ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                                ReadHandleToUSBDevice[fi] = CreateFile(DevicePath[fi], GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                                ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

                                if ((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
                                {
                                    AttachedState[fi] = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
                                    AttachedButBroken[fi] = false;
                                }
                                else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
                                {
                                    AttachedState[fi] = false;		//Let the rest of this application known not to read/write to the device.
                                    AttachedButBroken[fi] = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
                                    if (ErrorStatusWrite == ERROR_SUCCESS)
                                        WriteHandleToUSBDevice[fi].Close();
                                    if (ErrorStatusRead == ERROR_SUCCESS)
                                        ReadHandleToUSBDevice[fi].Close();
                                }
                            }
                            //else we did find the device, but AttachedState was already true.  In this case, don't do anything to the read/write handles,
                            //since the WM_DEVICECHANGE message presumably wasn't caused by our USB device.  
                        }
                        else	//Device must not be connected (or not programmed with correct firmware)
                        {
                            if (AttachedState[fi] == true)		//If it is currently set to true, that means the device was just now disconnected
                            {
                                AttachedState[fi] = false;
                                WriteHandleToUSBDevice[fi].Close();
                                ReadHandleToUSBDevice[fi].Close();
                            }
                            AttachedState[fi] = false;
                            AttachedButBroken[fi] = false;
                        }
                    }
                }
            } //end of: if(m.Msg == WM_DEVICECHANGE)

            base.WndProc(ref m);
        } //end of: WndProc() function
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void ReadWriteThread_DoWork(object sender, DoWorkEventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

            /*This thread does the actual USB read/write operations (but only when AttachedState == true) to the USB device.
            It is generally preferrable to write applications so that read and write operations are handled in a separate
            thread from the main form.  This makes it so that the main form can remain responsive, even if the I/O operations
            take a very long time to complete.

            Since this is a separate thread, this code below executes independently from the rest of the
            code in this application.  All this thread does is read and write to the USB device.  It does not update
            the form directly with the new information it obtains (such as the ANxx/POT Voltage or pushbutton state).
            The information that this thread obtains is stored in atomic global variables.
            Form updates are handled by the FormUpdateTimer Tick event handler function.

            This application sends packets to the endpoint buffer on the USB device by using the "WriteFile()" function.
            This application receives packets from the endpoint buffer on the USB device by using the "ReadFile()" function.
            Both of these functions are documented in the MSDN library.  Calling ReadFile() is a not perfectly straight
            foward in C# environment, since one of the input parameters is a pointer to a buffer that gets filled by ReadFile().
            The ReadFile() function is therefore called through a wrapper function ReadFileManagedBuffer().

            All ReadFile() and WriteFile() operations in this example project are synchronous.  They are blocking function
            calls and only return when they are complete, or if they fail because of some event, such as the user unplugging
            the device.  It is possible to call these functions with "overlapped" structures, and use them as non-blocking
            asynchronous I/O function calls.  

            Note:  This code may perform differently on some machines when the USB device is plugged into the host through a
            USB 2.0 hub, as opposed to a direct connection to a root port on the PC.  In some cases the data rate may be slower
            when the device is connected through a USB 2.0 hub.  This performance difference is believed to be caused by
            the issue described in Microsoft knowledge base article 940021:
            http://support.microsoft.com/kb/940021/en-us 

            Higher effective bandwidth (up to the maximum offered by interrupt endpoints), both when connected
            directly and through a USB 2.0 hub, can generally be achieved by queuing up multiple pending read and/or
            write requests simultaneously.  This can be done when using	asynchronous I/O operations (calling ReadFile() and
            WriteFile()	with overlapped structures).  The Microchip	HID USB Bootloader application uses asynchronous I/O
            for some USB operations and the source code can be used	as an example.*/

            Byte[] OUTBuffer = new byte[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
		    Byte[] INBuffer = new byte[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
		    uint BytesWritten = 0;
		    uint BytesRead = 0;
            /*USBから読み込み*/


            while (true)
            {
                try
                {
                    int unattached_count = 0;

                    for (int usb_idx = 0; usb_idx < USB_CONNECT_NUM; usb_idx++)
                    {
                        if (AttachedState[usb_idx] == true)
                        {
                            //Get ANxx/POT Voltage value from the microcontroller firmware.  Note: some demo boards may not have a pot
                            //on them.  In this case, the firmware may be configured to read an ANxx I/O pin voltage with the ADC
                            //instead.  If this is the case, apply a proper voltage to the pin.  See the firmware for exact implementation.

                            //VersionReadReq = false;
                            if (VersionReadReq[usb_idx] == true)
                            {
                                VersionReadReq[usb_idx] = false;

                                //Get the pushbutton state from the microcontroller firmware.
                                OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                OUTBuffer[1] = 0x56;		//0x81 is the "Get Pushbutton State" command in the firmware

                                for (uint i = 2; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                    OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                                //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                if (WriteFile(WriteHandleToUSBDevice[usb_idx], OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice[usb_idx], INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x56)
                                        {
                                            for (uint i = 2; i < 65; i++)
                                            {
                                                version_buff[usb_idx, i - 2] = INBuffer[i];
                                            }
                                            VersionReadComp[usb_idx] = true;
                                        }
                                    }
                                }
                                else
                                {
                                    AttachedState[usb_idx] = false;
                                }
                            }


                            if (b_LED_Ctrl_flag[usb_idx] == true)
                            {
                                if (DateTime.Now >= dt_ctrl_next_datetime[usb_idx])
                                {
                                    // LED制御データ・セット

                                    for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                        OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                    //Get the pushbutton state from the microcontroller firmware.
                                    OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                    OUTBuffer[1] = 0x31;		//0x81 is the "Get Pushbutton State" command in the firmware
                                    for (int fi = 0; fi < Constants.LED_NUM; fi++)
                                    {
                                        OUTBuffer[2 + fi] = read_data_led[usb_idx, ctrl_data_idx[usb_idx], fi];
                                    }


                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    if (WriteFile(WriteHandleToUSBDevice[usb_idx], OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        if (ReadFileManagedBuffer(ReadHandleToUSBDevice[usb_idx], INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                        {
                                            //INBuffer[0] is the report ID, which we don't care about.
                                            //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                            //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                            if (INBuffer[1] == 0x31)
                                            {
                                            }
                                        }
                                    }
                                    else
                                    {
                                        AttachedState[usb_idx] = false;
                                    }


                                    ctrl_data_idx[usb_idx]++;
                                    if (ctrl_data_idx[usb_idx] >= read_data_count[usb_idx])
                                    {
                                        if (b_loop_flag[usb_idx] == true)
                                        {   // ループ設定
                                            ctrl_data_idx[usb_idx] = 0;
                                            dt_ctrl_start_datetime[usb_idx] = DateTime.Now;
                                            dt_ctrl_next_datetime[usb_idx] = my_set_next_ctrl_time(dt_ctrl_start_datetime[usb_idx], read_data_time[usb_idx, ctrl_data_idx[usb_idx]]);
                                        }
                                        else
                                        {   // 全データ処理完了
                                            b_LED_Ctrl_flag[usb_idx] = false;
                                        }
                                    }
                                    else
                                    {   // 次のデータセット時間をセット
                                        dt_ctrl_next_datetime[usb_idx] = my_set_next_ctrl_time(dt_ctrl_start_datetime[usb_idx], read_data_time[usb_idx, ctrl_data_idx[usb_idx]]);
                                    }
                                }
                            }
                            if (b_led_off_set_req[usb_idx] == true)
                            {
                                b_led_off_set_req[usb_idx] = false;

                                for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                    OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                //Get the pushbutton state from the microcontroller firmware.
                                OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                OUTBuffer[1] = 0x31;		//0x81 is the "Get Pushbutton State" command in the firmware
                                for (int fi = 0; fi < Constants.LED_NUM; fi++)
                                {
                                    OUTBuffer[2 + fi] = 0;
                                }


                                //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                if (WriteFile(WriteHandleToUSBDevice[usb_idx], OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice[usb_idx], INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x31)
                                        {
                                        }
                                    }
                                }
                                else
                                {
                                    AttachedState[usb_idx] = false;
                                }
                            }

                        } //end of: if(AttachedState == true)
                        else
                        {
                            unattached_count++;
                            //Thread.Sleep(5);	//Add a small delay.  Otherwise, this while(true) loop can execute very fast and cause 
                            //high CPU utilization, with no particular benefit to the application.
                        }
                    }

                    if (unattached_count == USB_CONNECT_NUM)
                    {   // １台も接続されていない
                        Thread.Sleep(5);	//Add a small delay.  Otherwise, this while(true) loop can execute very fast and cause 
                        //high CPU utilization, with no particular benefit to the application.
                    }
                }
                catch
                {
                    //Exceptions can occur during the read or write operations.  For example,
                    //exceptions may occur if for instance the USB device is physically unplugged
                    //from the host while the above read/write functions are executing.

                    //Don't need to do anything special in this case.  The application will automatically
                    //re-establish communications based on the global AttachedState boolean variable used
                    //in conjunction with the WM_DEVICECHANGE messages to dyanmically respond to Plug and Play
                    //USB connection events.
                }

            } //end of while(true) loop
            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }
        public bool ReadFileManagedBuffer(SafeFileHandle hFile, byte[] INBuffer, uint nNumberOfBytesToRead, ref uint lpNumberOfBytesRead, IntPtr lpOverlapped)
        {
            IntPtr pINBuffer = IntPtr.Zero;

            try
            {
                pINBuffer = Marshal.AllocHGlobal((int)nNumberOfBytesToRead);    //Allocate some unmanged RAM for the receive data buffer.

                if (ReadFile(hFile, pINBuffer, nNumberOfBytesToRead, ref lpNumberOfBytesRead, lpOverlapped))
                {
                    Marshal.Copy(pINBuffer, INBuffer, 0, (int)lpNumberOfBytesRead);    //Copy over the data from unmanged memory into the managed byte[] INBuffer
                    Marshal.FreeHGlobal(pINBuffer);
                    return true;
                }
                else
                {
                    Marshal.FreeHGlobal(pINBuffer);
                    return false;
                }

            }
            catch
            {
                if (pINBuffer != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(pINBuffer);
                }
                return false;
            }
        }

        private void FormUpdateTimer_Tick_Tick(object sender, EventArgs e)
        {
            try
            {
                for (int usb_idx = 0; usb_idx < USB_CONNECT_NUM; usb_idx++)
                {
                    if (AttachedState[usb_idx] == true)
                    {

                        if (ConnectFirstTime[usb_idx] == true)
                        {
                            my_lbl_status[usb_idx].Text = string.Format(Constants.USB_CONNECT_MSG, usb_idx + 1);

                            VersionReadReq[usb_idx] = true;
                            VersionReadComp[usb_idx] = false;

                            btn_LED_Control_Start_Stop.Enabled = true;
                            btn_LED_Control_Start_Stop.Text = Constants.LED_CONTROL_START_STR;
                            b_LED_Ctrl_flag[usb_idx] = false;

                            ConnectFirstTime[usb_idx] = false;
                        }

                        if (VersionReadReq[usb_idx] == false && VersionReadComp[usb_idx] == true)
                        {
                            VersionReadComp[usb_idx] = false;
                            byte[] tmp_byte = new byte[version_buff.GetLength(1)];
                            for (int fi = 0; fi < version_buff.GetLength(1); fi++)
                            {
                                tmp_byte[fi] = version_buff[usb_idx, fi];
                            }
                            my_lbl_fw_version[usb_idx].Text = Constants.FW_VERSION + " " + Encoding.Default.GetString(tmp_byte);
                        }


                        UnConnectFirstTime[usb_idx] = true;
                    }
                    if ((AttachedState[usb_idx] == false) || (AttachedButBroken[usb_idx] == true))
                    {
                        //Device not available to communicate. Disable user interface on the form.
                        if (UnConnectFirstTime[usb_idx] == true)
                        {
                            my_lbl_status[usb_idx].Text = string.Format(Constants.USB_DISCONNECT_MSG, usb_idx + 1);

                            my_lbl_fw_version[usb_idx].Text = Constants.FW_VERSION;

                            btn_LED_Control_Start_Stop.Enabled = false;
                            btn_LED_Control_Start_Stop.Text = Constants.LED_CONTROL_START_STR;
                            b_LED_Ctrl_flag[usb_idx] = false;
                            my_gbx_file_select[usb_idx].Enabled = true;

                            UnConnectFirstTime[usb_idx] = false;
                        }
                    }



                    //Update the various status indicators on the form with the latest info obtained from the ReadWriteThread()
                    if (AttachedState[usb_idx] == true)
                    {
                        //DEBUG

                        // DEBUG
                    }
                }


                // LED制御がすべて終了しているか確認
                int led_ctrl_count = 0;
                for (int fi = 0; fi < USB_CONNECT_NUM; fi++)
                {
                    if (b_LED_Ctrl_flag[fi] == true && AttachedState[fi] == true)
                    {
                        led_ctrl_count++;
                    }
                }
                if (led_ctrl_count > 0)
                {   // LED制御中
                    for (int fi = 0; fi < USB_CONNECT_NUM; fi++ )
                    {
                        my_gbx_file_select[fi].Enabled = false;
                    }
                }
                else
                {
                    for (int fi = 0; fi < USB_CONNECT_NUM; fi++)
                    {
                        my_gbx_file_select[fi].Enabled = true;
                    }
                    btn_LED_Control_Start_Stop.Text = Constants.LED_CONTROL_START_STR;
                }
            }
            catch
            {
            }
        }

        private void btn_file_select_Click(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((Button)sender).Tag.ToString());
                if (0 <= idx && idx < Constants.USB_CONNECT_NUM_MAX)
                {
                    openFileDialog1.Title = Constants.FILE_OPEN_DIALOG_TITLE;
                    openFileDialog1.DefaultExt = Constants.FILE_EXTENSION;
                    openFileDialog1.Filter = Constants.FILE_FILTER;
                    openFileDialog1.FileName = "";
                    if (openFileDialog1.InitialDirectory == "")
                    {
                        //openFileDialog1.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                    }

                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {   // ファイル選択OK
                        my_txtbx_file_path[idx].Text = openFileDialog1.FileName;

                        int i_ret = my_LED_Ctrl_Data_File_Read(idx, openFileDialog1.FileName);
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_LED_Control_Start_Stop_Click(object sender, EventArgs e)
        {
            try
            {
                if (btn_LED_Control_Start_Stop.Text == Constants.LED_CONTROL_START_STR)
                {   // LED制御開始

                    // ファイル読み込み済みあり？
                    bool file_read_check = false;
                    for (int fi = 0; fi < Constants.USB_CONNECT_NUM_MAX; fi++)
                    {
                        if (b_file_read_comp[fi] == true)
                        {
                            file_read_check = true;
                            break;
                        }
                    }

                    if (file_read_check == true)
                    {   // ファイル読み込み済み
                        btn_LED_Control_Start_Stop.Text = Constants.LED_CONTROL_STOP_STR;

                        for (int fi = 0; fi < Constants.USB_CONNECT_NUM_MAX; fi++)
                        {
                            if (b_file_read_comp[fi] == true)
                            {
                                dt_ctrl_start_datetime[fi] = DateTime.Now;
                                ctrl_data_idx[fi] = 0;
                                dt_ctrl_next_datetime[fi] = my_set_next_ctrl_time(dt_ctrl_start_datetime[fi], read_data_time[fi, ctrl_data_idx[fi]]);

                                b_LED_Ctrl_flag[fi] = true;
                            }
                        }
                    }
                }
                else
                {   // LED 制御停止
                    for (int fi = 0; fi < Constants.USB_CONNECT_NUM_MAX; fi++)
                    {
                        b_LED_Ctrl_flag[fi] = false;
                    }
                    btn_LED_Control_Start_Stop.Text = Constants.LED_CONTROL_START_STR;
                    for (int fi = 0; fi < Constants.USB_CONNECT_NUM_MAX; fi++)
                    {
                        b_led_off_set_req[fi] = true;
                    }
                }
            }
            catch
            {
            }
        }

        private int my_LED_Ctrl_Data_File_Read(int p_idx, string file_name)
        {
            int ret = -1;
            bool b_error_flag = false;
            int read_count = 0;
            double pre_time = 0;
            try
            {
#if true   // CSV
                if (0 <= p_idx && p_idx < Constants.USB_CONNECT_NUM_MAX)
                {
                    System.Text.Encoding enc = System.Text.Encoding.GetEncoding("Shift_JIS");
                    //System.Text.Encoding enc = System.Text.Encoding.GetEncoding("UTF-8");
                    System.IO.StreamReader sr = null;
                    try
                    {
                        sr = new System.IO.StreamReader(file_name, enc);
                        string line_read_data = "";

                        int line_no = 1;

                        //内容を一行ずつ読み込む
                        while (sr.Peek() > -1)
                        {
                            line_read_data = sr.ReadLine();

                            if (line_read_data.IndexOf("#") == 0)
                            {
                                // コメント
                            }
                            else
                            {
                                try
                                {
                                    string[] in_str_arry = new string[1];
                                    if (CommonFunc.my_csv_to_array_buff(line_read_data, ref in_str_arry) >= (1 + Constants.LED_NUM))
                                    {
                                        // 時間
                                        if (0 < in_str_arry[0].Length && in_str_arry[0].Length <= Constants.TIME_MAX_CHAR)
                                        {
                                            try
                                            {
                                                read_data_time[p_idx, read_count] = double.Parse(in_str_arry[0]);

                                                if (pre_time > read_data_time[p_idx, read_count])
                                                {   // 今回読み込んだ時間データが小さい
                                                    ret = -5;
                                                    b_error_flag = true;
                                                }
                                                pre_time = read_data_time[p_idx, read_count];
                                            }
                                            catch
                                            {
                                                ret = -4;
                                                b_error_flag = true;
                                            }
                                        }
                                        else
                                        {
                                            ret = -4;
                                            b_error_flag = true;
                                        }

                                        byte[] data_arry = new byte[Constants.LED_NUM];
                                        for (int fi = 0; fi < Constants.LED_NUM; fi++)
                                        {
                                            try
                                            {
                                                data_arry[fi] = (byte)(int.Parse(in_str_arry[fi + 1]) & 0xFF);
                                                if (data_arry[fi] > 100)
                                                {   // データが、100超え
                                                    data_arry[fi] = 0;

                                                    ret = -3;
                                                    b_error_flag = true;
                                                }
                                                else
                                                {
                                                    read_data_led[p_idx, read_count, fi] = data_arry[fi];
                                                }
                                            }
                                            catch
                                            {
                                                ret = -3;
                                                b_error_flag = true;
                                            }
                                        }

                                        read_count++;
                                        if (read_count >= Constants.READ_DATA_MAX)
                                        {   // 読み込み上限超過
                                            break;
                                        }
                                    }
                                    else
                                    {   // 1行のデータ数が少ない
                                        ret = -2;
                                        b_error_flag = true;
                                    }

                                }
                                catch
                                {
                                    ret = -1;
                                    b_error_flag = true;
                                }
                            }
                            line_no++;

                            if (b_error_flag == true)
                            {
                                break;
                            }
                        }
                    }
                    catch
                    {
                        ret = -1;
                        b_error_flag = true;
                    }
                    finally
                    {
                        if (sr != null)
                        {
                            sr.Close();
                            sr.Dispose();
                        }
                    }

                    if (b_error_flag == false)
                    {
                        ret = read_count;
                    }
                    else
                    {
                        // Read Error
                    }
                }
#endif
            }
            catch
            {
            }
            finally
            {
                if (0 <= p_idx && p_idx < Constants.USB_CONNECT_NUM_MAX)
                {
                    if (ret > 0)
                    {   // 読み込み成功
                        read_data_count[p_idx] = ret;
                        b_file_read_comp[p_idx] = true;
                        my_txtbx_read_result[p_idx].Text = Constants.LED_CTRL_DATA_FILE_READ_SUCCESS_MSG1;
                    }
                    else
                    {   // 読み込み失敗
                        read_data_count[p_idx] = 0;
                        b_file_read_comp[p_idx] = false;

                        if (ret == -2)
                        {
                            my_txtbx_read_result[p_idx].Text = Constants.LED_CTRL_DATA_FILE_READ_ERROR_MSG2;
                        }
                        else if (ret == -3)
                        {
                            my_txtbx_read_result[p_idx].Text = Constants.LED_CTRL_DATA_FILE_READ_ERROR_MSG3;
                        }
                        else if (ret == -4)
                        {
                            my_txtbx_read_result[p_idx].Text = Constants.LED_CTRL_DATA_FILE_READ_ERROR_MSG4;
                        }
                        else if (ret == -5)
                        {
                            my_txtbx_read_result[p_idx].Text = Constants.LED_CTRL_DATA_FILE_READ_ERROR_MSG5;
                        }
                        else
                        {
                            my_txtbx_read_result[p_idx].Text = Constants.LED_CTRL_DATA_FILE_READ_ERROR_MSG1;
                        }
                    }
                }
            }
            return ret;
        }

        private DateTime my_set_next_ctrl_time(DateTime p_start_time, double p_next_time_span)
        {
            DateTime ret_val = p_start_time;
            try
            {
                ret_val = p_start_time.AddMilliseconds(p_next_time_span * 1000);
            }
            catch
            {
            }
            return ret_val;
        }

        private void chkbx_loop_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((CheckBox)sender).Tag.ToString());
                if (0 <= idx && idx < Constants.USB_CONNECT_NUM_MAX)
                {
                    b_loop_flag[idx] = my_chkbx_loop[idx].Checked;
                }
            }
            catch
            {
            }
        }

        private void gbx_fileselect_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                int idx = int.Parse(((GroupBox)sender).Tag.ToString());
                if (0 <= idx && idx < Constants.USB_CONNECT_NUM_MAX)
                {
                    if (e.Effect == DragDropEffects.Move)
                    {
                        if (e.Data.GetDataPresent(DataFormats.FileDrop))
                        {
                            //ドロップされたすべてのファイル名を取得する
                            string[] fileName = (string[])e.Data.GetData(DataFormats.FileDrop, false);
                            string file_ex = Path.GetExtension(fileName[0]);
                            file_ex = file_ex.ToLower();

                            // CSV or TXT ファイルの場合
                            if (file_ex == ".csv")
                            {
                                try
                                {
                                    my_txtbx_file_path[idx].Text = fileName[0];

                                    int i_ret = my_LED_Ctrl_Data_File_Read(idx, fileName[0]);
                                }
                                catch
                                {
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
            }
        }

        private void gbx_fileselect_DragOver(object sender, DragEventArgs e)
        {
            try
            {
                e.Effect = DragDropEffects.Move;
            }
            catch
            {
            }
        }

    }


    static class CommonFunc
    {
        /// 指定された文字列内にある文字が幾つあるか数える
        public static int my_Count_String(string strInput, string strFind)
        {
            int foundCount = 0;
            int sPos = strInput.IndexOf(strFind);
            while (sPos > -1)
            {
                foundCount++;
                sPos = strInput.IndexOf(strFind, sPos + 1);
            }

            return foundCount;
        }
        /// 文字列をダブルクォートで囲む
        public static string my_Enclose_Double_Quotes(string field)
        {
            if (field.IndexOf('"') > -1)
            {
                //"を""とする
                field = field.Replace("\"", "\"\"");
            }
            return "\"" + field + "\"";
        }
        public static int my_csv_to_array_buff(string p_csv_text, ref string[] o_csv_buff)
        {
            int i_ret = 0;
            try
            {
                //前後の改行を削除しておく
                p_csv_text = p_csv_text.Trim(new char[] { '\r', '\n' });

                //1行のCSVから各フィールドを取得するための正規表現
                System.Text.RegularExpressions.Regex regCsv =
                    new System.Text.RegularExpressions.Regex(
                    "\\s*(\"(?:[^\"]|\"\")*\"|[^,]*)\\s*,",
                    System.Text.RegularExpressions.RegexOptions.None);

                // "の数が偶数個か調べる
                if ((my_Count_String(p_csv_text, "\"") % 2) == 0)
                {
                    //行の最後の改行記号を削除
                    p_csv_text = p_csv_text.TrimEnd(new char[] { '\r', '\n' });
                    //最後に「,」をつける
                    p_csv_text += ",";

                    //1つの行からフィールドを取り出す
                    System.Collections.ArrayList csvFields = new System.Collections.ArrayList();
                    System.Text.RegularExpressions.Match m = regCsv.Match(p_csv_text);
                    while (m.Success)
                    {
                        string field = m.Groups[1].Value;
                        //前後の空白を削除
                        field = field.Trim();
                        //"で囲まれている時
                        if (field.StartsWith("\"") && field.EndsWith("\""))
                        {
                            //前後の"を取る
                            field = field.Substring(1, field.Length - 2);
                            //「""」を「"」にする
                            field = field.Replace("\"\"", "\"");
                        }
                        csvFields.Add(field);
                        m = m.NextMatch();
                    }

                    csvFields.TrimToSize();

                    // 出力バッファにセット
                    o_csv_buff = new string[csvFields.Count];
                    for (int fi = 0; fi < csvFields.Count; fi++)
                    {
                        o_csv_buff[fi] = csvFields[fi].ToString();
                    }
                    i_ret = csvFields.Count;
                }
                else
                {   // "の数が奇数
                    i_ret = -1;
                }
            }
            catch
            {
            }
            return i_ret;
        }
    }

    static class Constants
    {
        public const string FW_VERSION = "FW Version : ";        /* FW Version */
        public const int USB_CONNECT_NUM_MAX = 5;
        public const string USB_CONNECT_MSG = "制御基板No.{0} 接続されました";
        public const string USB_DISCONNECT_MSG = "制御基板No.{0} 未接続";
        public const string LED_CONTROL_START_STR = "LED制御開始";
        public const string LED_CONTROL_STOP_STR = "LED制御停止";

        public const int LED_NUM = 10;
        public const int READ_DATA_MAX = 0x10000;    // 100ms = 1data, 1s=10, 1m=600, 60m=36000
        public const int TIME_MAX_CHAR = 16;         // 時間設定の最大文字列数

        public const string FILE_OPEN_DIALOG_TITLE = "LED制御ファイルを選択してください";
        public const string FILE_EXTENSION = ".csv";
        public const string FILE_FILTER = "CSV File(*.csv)|*.csv";
        public const string LED_CTRL_DATA_FILE_READ_SUCCESS_MSG1 = "LED制御ファイルの読み込み成功";
        public const string LED_CTRL_DATA_FILE_READ_ERROR_MSG1 = "LED制御ファイルの読み込みエラー";
        public const string LED_CTRL_DATA_FILE_READ_ERROR_MSG2 = "LED制御ファイルの読み込みエラー : データが少ない行があります";
        public const string LED_CTRL_DATA_FILE_READ_ERROR_MSG3 = "LED制御ファイルの読み込みエラー : PWM値が100を超えているデータがあります";
        public const string LED_CTRL_DATA_FILE_READ_ERROR_MSG4 = "LED制御ファイルの読み込みエラー : 時間データ異常";
        public const string LED_CTRL_DATA_FILE_READ_ERROR_MSG5 = "LED制御ファイルの読み込みエラー : 時間データが誤りがあります";
    }
}
