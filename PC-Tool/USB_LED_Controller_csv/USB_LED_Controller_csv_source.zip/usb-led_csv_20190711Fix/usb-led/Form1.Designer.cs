﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.gbx_fileselect = new System.Windows.Forms.GroupBox();
            this.txtbx_file_read_result = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbx_file_path = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_file_select = new System.Windows.Forms.Button();
            this.btn_LED_Control_Start_Stop = new System.Windows.Forms.Button();
            this.lbl_FW_Version = new System.Windows.Forms.Label();
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.FormUpdateTimer_Tick = new System.Windows.Forms.Timer(this.components);
            this.chkbx_loop = new System.Windows.Forms.CheckBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.gbx_fileselect.SuspendLayout();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // gbx_fileselect
            // 
            this.gbx_fileselect.Controls.Add(this.txtbx_file_read_result);
            this.gbx_fileselect.Controls.Add(this.label2);
            this.gbx_fileselect.Controls.Add(this.txtbx_file_path);
            this.gbx_fileselect.Controls.Add(this.label1);
            this.gbx_fileselect.Controls.Add(this.btn_file_select);
            this.gbx_fileselect.Location = new System.Drawing.Point(12, 12);
            this.gbx_fileselect.Name = "gbx_fileselect";
            this.gbx_fileselect.Size = new System.Drawing.Size(728, 87);
            this.gbx_fileselect.TabIndex = 100;
            this.gbx_fileselect.TabStop = false;
            this.gbx_fileselect.Text = "ファイル選択";
            // 
            // txtbx_file_read_result
            // 
            this.txtbx_file_read_result.Location = new System.Drawing.Point(128, 57);
            this.txtbx_file_read_result.Name = "txtbx_file_read_result";
            this.txtbx_file_read_result.ReadOnly = true;
            this.txtbx_file_read_result.Size = new System.Drawing.Size(513, 19);
            this.txtbx_file_read_result.TabIndex = 111;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(22, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 110;
            this.label2.Text = "読み込み結果";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_file_path
            // 
            this.txtbx_file_path.Location = new System.Drawing.Point(63, 33);
            this.txtbx_file_path.Name = "txtbx_file_path";
            this.txtbx_file_path.ReadOnly = true;
            this.txtbx_file_path.Size = new System.Drawing.Size(578, 19);
            this.txtbx_file_path.TabIndex = 102;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(15, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 23);
            this.label1.TabIndex = 101;
            this.label1.Text = "File";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_file_select
            // 
            this.btn_file_select.Location = new System.Drawing.Point(643, 31);
            this.btn_file_select.Name = "btn_file_select";
            this.btn_file_select.Size = new System.Drawing.Size(75, 23);
            this.btn_file_select.TabIndex = 103;
            this.btn_file_select.Text = "選択";
            this.btn_file_select.UseVisualStyleBackColor = true;
            this.btn_file_select.Click += new System.EventHandler(this.btn_file_select_Click);
            // 
            // btn_LED_Control_Start_Stop
            // 
            this.btn_LED_Control_Start_Stop.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_LED_Control_Start_Stop.Location = new System.Drawing.Point(261, 110);
            this.btn_LED_Control_Start_Stop.Name = "btn_LED_Control_Start_Stop";
            this.btn_LED_Control_Start_Stop.Size = new System.Drawing.Size(231, 29);
            this.btn_LED_Control_Start_Stop.TabIndex = 200;
            this.btn_LED_Control_Start_Stop.Text = "LED制御開始";
            this.btn_LED_Control_Start_Stop.UseVisualStyleBackColor = true;
            this.btn_LED_Control_Start_Stop.Click += new System.EventHandler(this.btn_LED_Control_Start_Stop_Click);
            // 
            // lbl_FW_Version
            // 
            this.lbl_FW_Version.Location = new System.Drawing.Point(552, 139);
            this.lbl_FW_Version.Name = "lbl_FW_Version";
            this.lbl_FW_Version.Size = new System.Drawing.Size(187, 23);
            this.lbl_FW_Version.TabIndex = 901;
            this.lbl_FW_Version.Text = "version";
            this.lbl_FW_Version.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.Location = new System.Drawing.Point(10, 139);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(380, 23);
            this.StatusBox_lbl.TabIndex = 900;
            this.StatusBox_lbl.Text = "status";
            this.StatusBox_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // FormUpdateTimer_Tick
            // 
            this.FormUpdateTimer_Tick.Enabled = true;
            this.FormUpdateTimer_Tick.Tick += new System.EventHandler(this.FormUpdateTimer_Tick_Tick);
            // 
            // chkbx_loop
            // 
            this.chkbx_loop.AutoSize = true;
            this.chkbx_loop.Location = new System.Drawing.Point(130, 117);
            this.chkbx_loop.Name = "chkbx_loop";
            this.chkbx_loop.Size = new System.Drawing.Size(48, 16);
            this.chkbx_loop.TabIndex = 112;
            this.chkbx_loop.Text = "Loop";
            this.chkbx_loop.UseVisualStyleBackColor = true;
            this.chkbx_loop.CheckedChanged += new System.EventHandler(this.chkbx_loop_CheckedChanged);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(752, 165);
            this.Controls.Add(this.chkbx_loop);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.lbl_FW_Version);
            this.Controls.Add(this.btn_LED_Control_Start_Stop);
            this.Controls.Add(this.gbx_fileselect);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "USB LED Controller Configration Tool";
            this.gbx_fileselect.ResumeLayout(false);
            this.gbx_fileselect.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.GroupBox gbx_fileselect;
        private System.Windows.Forms.TextBox txtbx_file_read_result;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtbx_file_path;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_file_select;
        private System.Windows.Forms.Button btn_LED_Control_Start_Stop;
        private System.Windows.Forms.Label lbl_FW_Version;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.Timer FormUpdateTimer_Tick;
        private System.Windows.Forms.CheckBox chkbx_loop;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

