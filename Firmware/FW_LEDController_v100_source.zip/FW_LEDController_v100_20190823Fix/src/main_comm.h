#ifndef MAIN_COMM_H
#define MAIN_COMM_H

#include "app.h"
#include "./USB/usb.h"
#include "./USB/usb_function_hid.h"


extern void USB_Comm(void);


#endif //MAIN_COMM_H

