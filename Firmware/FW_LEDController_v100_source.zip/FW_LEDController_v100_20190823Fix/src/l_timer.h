#ifndef L_TIMER_H
#define L_TIMER_H

//#include <timers.h>
#include "app.h"


//--------------------------------------------------
//Timer
// FREQ / Prescale / X
// 1 / X second(1ms�Ȃ�1/1000sec�Ȃ̂�X=1000)
//--------------------------------------------------
/***** Timer1 *****/
/* Timer1�́A�ԊO���o�͎��g���Ƃ��� */
/* �v�Z�� �V�X�e�����g��[kHz] / �ԊO���o�͎��g��[kHz] */
/* �v�Z 40,000[kHz] / 38[kHz] = 1052 */
#if 0
/* Timer1 0.026ms */
/* FREQ=40MHz, Prescale=1, X=1/38000sec */
/* 40MHz / 1 / 38000 = 1052(0x041C) */
#define TIMER1_PERIOD        0x041C        //Timer1�̎���
#endif
#if 1
/* Timer1 1ms */
/* FREQ=40MHz, Prescale=1, X=1/1000sec */
/* 40MHz / 1 / 1000 = 40,000(0x9C40) */
#define TIMER1_PERIOD        0x0FA0        //Timer1�̎���
#endif
/***** Timer2 *****/
/* Timer2 1ms */
/* FREQ=40MHz, Prescale=1, X=1/1000sec */
/* 40MHz / 1 / 1000 = 40,000(0x9C40) */
#define TIMER2_PERIOD        0x0FA0        //Timer2s�̎���


extern void timer1_init(void);
extern void timer2_init(void);
extern void timer4_init(void);
extern void Timer1_Task(void);
extern void Timer2_Task(void);



#endif //L_TIMER_H
