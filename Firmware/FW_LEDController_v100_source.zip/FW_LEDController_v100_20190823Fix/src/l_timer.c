#include "app.h"
#include "l_timer.h"
#include "main_sub.h"


void timer1_init(void);
void timer2_init(void);
void timer4_init(void);
void Timer1_Task(void);
void Timer2_Task(void);

WORD l_timer2_counter = 0;
int fi = 0;


// Timer1 ������
// 1ms
void timer1_init(void)
{
    T1CONbits.ON = 0;       // Timer1 OFF
    TMR1 = 0;
    PR1 = TIMER1_PERIOD;
    T1CONbits.TCKPS = 0;    // 0=1:1, 1=1:8, 2=1:64, 3=1:256 prescale
    T1CONbits.TCS = 0;      // Internal clock
    IPC1bits.T1IP = 3;      // interrupt priority
    IPC1bits.T1IS = 1;      // interrupt subpriority
    IFS0bits.T1IF = 0;      // clear timer1 interrupt flag
    IEC0bits.T1IE = 1;      // enable timer1 interrupt
    T1CONbits.ON = 1;       // Timer1 ON
}

// Timer2 ������
// 1ms
void timer2_init(void)
{
    T2CONbits.ON = 0;       // Timer2 OFF
    TMR2 = 0;
    PR2 = TIMER2_PERIOD;
    T2CONbits.TCKPS = 0;    // 0=1:1, 1=1:2, 2=1:4, 3=1:8, 4=1:16, 5=1:32, 6=1:64, 7=1:256 prescale
    T2CONbits.T32 = 0;      // 16-bit timer
    IPC2bits.T2IP = 3;      // interrupt priority
    IPC2bits.T2IS = 1;      // interrupt subpriority
    IFS0bits.T2IF = 0;      // clear timer2 interrupt flag
    IEC0bits.T2IE = 1;      // enable timer2 interrupt
    T2CONbits.ON = 1;       // Timer2 ON
}

// Timer4 ������
// 32bit
// 1ms
void timer4_init(void)
{
    T4CONbits.ON = 0;       // Timer4 OFF
    TMR4 = 0;
    PR4 = 0;
    T4CONbits.TCKPS = 1;    // 0=1:1, 1=1:2, 2=1:4, 3=1:8, 4=1:16, 5=1:32, 6=1:64, 7=1:256 prescale
    T4CONbits.T32 = 1;      // 0=16bit, 1=32bit timer
//    IPC4bits.T4IP = 3;      // interrupt priority
//    IPC4bits.T4IS = 1;      // interrupt subpriority
    IFS0bits.T4IF = 0;      // clear timer4 interrupt flag
    IEC0bits.T4IE = 0;      // disable timer4 interrupt
    T4CONbits.ON = 1;       // Timer4 ON
}

// Timer1 Task
void Timer1_Task(void)
{
    IFS0bits.T1IF = 0;

//    LATFbits.LATF5 = ~LATFbits.LATF5;
	output_duty_count++;
	if(output_duty_count >= LED_MAX_DUTY)
	{
		output_duty_count = 0;
	}
	for(fi = 0; fi < OUTPUT_NUM; fi++)
	{
		(output_duty_count >= output_fix[fi]) ? set_LED((fi+1),OUTPUT_OFF) : set_LED((fi+1),OUTPUT_ON);
	}            
    debug_arr1[1]++;
}

// Timer2 Task
void Timer2_Task(void)
{
    IFS0bits.T2IF = 0;

    
    
    debug_arr1[2]++;
}
