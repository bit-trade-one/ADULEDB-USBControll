#ifndef MAIN_SUB_H
#define MAIN_SUB_H

#include "app.h"

// Timer4
// 40MHz �v���X�P�[��2
// TMR�̃J�E���g��0.05us
#define SOFT_DELAY_1US      20
#define SOFT_DELAY_5US      100
#define SOFT_DELAY_10US     200
#define SOFT_DELAY_100US    2000
#define SOFT_DELAY_1MS      20000
#define SOFT_DELAY_10MS     200000
#define SOFT_DELAY_100MS    2000000

extern void Soft_Delay(DWORD delayValue);
extern void Switch_Input(void);


#endif //MAIN_SUB_H

