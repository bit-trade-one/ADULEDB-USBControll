/*******************************************************************************
 CAN WiFi

  Company:


  File Name:
    app.h

  Summary:
    Application specific header file.

  Description:
    Application specific header file.
 *******************************************************************************/

#ifndef APP_H
#define	APP_H


// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#include "xc.h"
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "GenericTypeDefs.h"
#include "./USB/usb.h"
//#include "usb_config.h"



#if 0
typedef uint8_t		BYTE;                           /* 8-bit unsigned  */
typedef uint16_t	WORD;                           /* 16-bit unsigned */
typedef uint32_t	DWORD;                          /* 32-bit unsigned */

typedef union
{
    WORD Val;
    BYTE v[2];
    struct
    {
        BYTE LB;
        BYTE HB;
    } byte;
} WORD_VAL;

typedef union
{
    DWORD Val;
    WORD w[2];
    BYTE v[4];
    struct
    {
        WORD LW;
        WORD HW;
    } word;
    struct
    {
        BYTE LB;
        BYTE HB;
        BYTE UB;
        BYTE MB;
    } byte;
} DWORD_VAL;
#endif

/** DECLARATIONS ***************************************************/
#define SW_1_NO             PORTAbits.RA0
#define SW_2_NO             PORTBbits.RB13
#define SW_NUM				2		// SW���͐�
#define	SW_1_NO_IDX			0
#define	SW_2_NO_IDX			1
#define SW_ON_DEFAULT_COUNT		16		// SW ON�����
#define	SW_OFF_DEFAULT_COUNT		16		// SW OFF�����
#define SW_ON_DEBOUNCE_TIME		20		// SW ON�f�o�E���X�^�C��
#define SW_OFF_DEBOUNCE_TIME		20		// SW OFF�f�o�E���X�^�C��


#define LED_BUFF_SIZE   6
#define OUTPUT_NUM  10
#define LED_0X_NUM   3
#define LED_1X_NUM   9
#define LED_2X_NUM   9
#define LED_3X_NUM   9
#define LED_4X_NUM   9
#define LED_5X_NUM   9

//#define LED1_ONOFF_INTERVAL     1000        // LED1�̓_�Ŏ���[ms] ���̎��ԊԊu��ON/OFF���J��Ԃ�
//#define LED2_ON_TIME            10
#define LED01                    LATAbits.LATA0
#define LED01_ON()               LATAbits.LATA0=1
#define LED01_OFF()              LATAbits.LATA0=0
#define LED02                    LATAbits.LATA1
#define LED02_ON()               LATAbits.LATA1=1
#define LED02_OFF()              LATAbits.LATA1=0
#define LED03                    LATBbits.LATB0
#define LED03_ON()               LATBbits.LATB0=1
#define LED03_OFF()              LATBbits.LATB0=0
#define LED04                    LATBbits.LATB1
#define LED04_ON()               LATBbits.LATB1=1
#define LED04_OFF()              LATBbits.LATB1=0
#define LED05                    LATBbits.LATB2
#define LED05_ON()               LATBbits.LATB2=1
#define LED05_OFF()              LATBbits.LATB2=0
#define LED06                    LATBbits.LATB3
#define LED06_ON()               LATBbits.LATB3=1
#define LED06_OFF()              LATBbits.LATB3=0
#define LED07                    LATBbits.LATB8
#define LED07_ON()               LATBbits.LATB8=1
#define LED07_OFF()              LATBbits.LATB8=0
#define LED08                    LATBbits.LATB9
#define LED08_ON()               LATBbits.LATB9=1
#define LED08_OFF()              LATBbits.LATB9=0
#define LED09                    LATBbits.LATB14
#define LED09_ON()               LATBbits.LATB14=1
#define LED09_OFF()              LATBbits.LATB14=0
#define LED10                    LATBbits.LATB15
#define LED10_ON()               LATBbits.LATB15=1
#define LED10_OFF()              LATBbits.LATB15=0

#define OUTPUT_OFF 0
#define OUTPUT_ON 1

#define LED_MAX_DUTY 100

#define RX_DATA_BUFFER_ADDRESS
#define TX_DATA_BUFFER_ADDRESS

#define RX_DATA_BUFFER_SIZE     64
#define TX_DATA_BUFFER_SIZE     64

#define N_ON    1		// normal ON
#define N_OFF   0		// normal OFF
#define R_ON    0		// reverse ON
#define R_OFF   1		// reverse OFF



//--------------------------------------------------
//�f�B���C�֐�
//--------------------------------------------------
// 40MHz = 1���� 0.025us
// 1us = 40���� = Delay10TCY(4);
// 5us = 200���� = Delay10TCYx(20);
// 10us = 400���� = Delay100TCYx(4);
// 50us = 2,000���� = Delay100TCYx(20);
// 100us = 4,000���� = Delay100TCYx(40);
// 1ms = 40,000���� = Delay10KTCYx(4);
// 10ms = 400,000���� = Delay10KTCYx(40);
// 100ms = 4,000,000���� = Delay10KTCYx(400)
#define DELAY_1us() Delay10TCYx(4)
#define DELAY_5us() Delay10TCYx(20)
#define DELAY_10us() Delay100TCYx(4)
#define DELAY_50us() Delay100TCYx(20)
#define DELAY_100us() Delay100TCYx(40)
#define DELAY_1ms() Delay10KTCYx(4)
#define DELAY_5ms() Delay10KTCYx(20)
#define DELAY_10ms() Delay10KTCYx(40)
#define DELAY_50ms() Delay10KTCYx(200)
#define DELAY_100ms() Delay10KTCYx(400)

extern void USBCBSendResume(void);
extern void set_LED(unsigned char no, unsigned char onoff);

/*********************************************************
 * Extern symbols
 ********************************************************/


extern int8_t	c_version[];
extern BYTE sw_now_fix[SW_NUM];
extern BYTE sw_now_fix_pre[SW_NUM];
extern BYTE sw_press_on_cnt[SW_NUM];
extern BYTE sw_press_off_cnt[SW_NUM];
extern int led2_output_counter;
extern WORD timer1_counter;
extern WORD timer2_counter;

extern WORD LED_Out[LED_BUFF_SIZE];

extern BYTE ReceivedDataBuffer[RX_DATA_BUFFER_SIZE] RX_DATA_BUFFER_ADDRESS;
extern BYTE ToSendDataBuffer[TX_DATA_BUFFER_SIZE] TX_DATA_BUFFER_ADDRESS;

extern BYTE output_fix[OUTPUT_NUM];
extern BYTE output_fix_pre[OUTPUT_NUM];
extern BYTE output_duty_count;	//led�_���pduty�̓����l

extern USB_HANDLE USBOutHandle;
extern USB_HANDLE USBInHandle;
//extern USB_HANDLE lastTransmission_Mouse;
//extern USB_HANDLE lastTransmission_Volume;
//extern USB_HANDLE lastINTransmission_Keyboard;
//extern USB_HANDLE lastOUTTransmission_Keyboard;

// DEBUG
extern BYTE debug_arr1[16];
extern BYTE debug_arr2[16];
extern WORD debug_array_w1[16];


#endif	/* APP_H */

