#include <string.h>
#include "app.h"
#include "Main_comm.h"


void USB_Comm(void)
{
    BYTE fi,fj;
    WORD temp_w = 0;
    int8_t tmp;
	BYTE prevLED[OUTPUT_NUM] = {0};
// USB Data
    //Check if we have received an OUT data packet from the host
    if(!HIDRxHandleBusy(USBOutHandle))
    {
        for(fi = 0; fi < TX_DATA_BUFFER_SIZE; fi++)
        {
            ToSendDataBuffer[fi] = 0x00;
        }
        //We just received a packet of data from the USB host.
        //Check the first byte of the packet to see what command the host
        //application software wants us to fulfill.
        switch(ReceivedDataBuffer[0])				//Look at the data the host sent, to see what kind of application specific command it sent.
        {
            case 0x56: // V=0x56 Get Firmware version
                ToSendDataBuffer[0] = 0x56;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Pushbutton State command.
                tmp = strlen(c_version);
                if( 0 < tmp && tmp <= (64-2) )
                {
                        for( fi = 0; fi < tmp; fi++ )
                        {
                                ToSendDataBuffer[fi+1] = c_version[fi];
                        }
                        // �Ō��NULL������ݒ�
                        ToSendDataBuffer[fi+1] = 0x00;
                }
                else
                {
                        //�o�[�W����������ُ�
                        ToSendDataBuffer[1] = 0x00;
                }
                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP,(BYTE*)&ToSendDataBuffer[0], sizeof(ToSendDataBuffer));
                }
                break;
            case 0x21:  // LEDDuty���M [0x21]
                ToSendDataBuffer[0] = 0x21;

				for(fi = 0; fi < OUTPUT_NUM; fi++){
					ToSendDataBuffer[fi+1] = output_fix[fi];
				}
				
                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP,(BYTE*)&ToSendDataBuffer[0], sizeof(ToSendDataBuffer));
                }
                break;
            case 0x22:  // LEDDuty�ݒ� [0x22]
                ToSendDataBuffer[0] = 0x22;

				if(ReceivedDataBuffer[1] <= OUTPUT_NUM - 1){
					if(ReceivedDataBuffer[2] <= LED_MAX_DUTY){
						output_fix[ReceivedDataBuffer[1]] = ReceivedDataBuffer[2];
						ToSendDataBuffer[1] = 0x00;
				    // OK�A���T
					}else{
						ToSendDataBuffer[1] = 0xFF;
					}
				}else{
					ToSendDataBuffer[1] = 0xFF;
				}
                              
                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP,(BYTE*)&ToSendDataBuffer[0], sizeof(ToSendDataBuffer));
                }
                break;
            case 0x31:  // LED�ꊇ���� [0x31]
                ToSendDataBuffer[0] = 0x31;
				for(fi = 0; fi < OUTPUT_NUM; fi++){
					prevLED[fi] = output_fix[fi];
					if(ReceivedDataBuffer[fi+1] > LED_MAX_DUTY){
						for(fj = 0; fj < OUTPUT_NUM; fj++){
							output_fix[fj] = prevLED[fj];
						}
						ToSendDataBuffer[1] = 0xFF;
						break;
					}else{
						output_fix[fi] = ReceivedDataBuffer[fi+1];
					}					
				}
				
                // OK�A���T
                ToSendDataBuffer[1] = 0x00;

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP,(BYTE*)&ToSendDataBuffer[0], sizeof(ToSendDataBuffer));
                }
                break;
#if 1	//DEBUG
            case 0x40:
                ToSendDataBuffer[0] = 0x40;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Pushbutton State command.
                ToSendDataBuffer[1] = debug_arr1[0];
                ToSendDataBuffer[2] = debug_arr1[1];
                ToSendDataBuffer[3] = debug_arr1[2];
                ToSendDataBuffer[4] = debug_arr1[3];
                ToSendDataBuffer[5] = debug_arr1[4];
                ToSendDataBuffer[6] = debug_arr1[5];
                ToSendDataBuffer[7] = debug_arr1[6];
                ToSendDataBuffer[8] = debug_arr1[7];
                ToSendDataBuffer[9] = debug_arr1[8];
                ToSendDataBuffer[10] = debug_arr1[9];
                ToSendDataBuffer[11] = debug_arr1[10];
                ToSendDataBuffer[12] = debug_arr1[11];
                ToSendDataBuffer[13] = debug_arr1[12];
                ToSendDataBuffer[14] = debug_arr1[13];
                ToSendDataBuffer[15] = debug_arr1[14];
                ToSendDataBuffer[16] = debug_arr1[15];

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
            case 0x41:
                ToSendDataBuffer[0] = 0x41;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Pushbutton State command.
                ToSendDataBuffer[1] = debug_arr2[0];
                ToSendDataBuffer[2] = debug_arr2[1];
                ToSendDataBuffer[3] = debug_arr2[2];
                ToSendDataBuffer[4] = debug_arr2[3];
                ToSendDataBuffer[5] = debug_arr2[4];
                ToSendDataBuffer[6] = debug_arr2[5];
                ToSendDataBuffer[7] = debug_arr2[6];
                ToSendDataBuffer[8] = debug_arr2[7];
                ToSendDataBuffer[9] = debug_arr2[8];
                ToSendDataBuffer[10] = debug_arr2[9];
                ToSendDataBuffer[11] = debug_arr2[10];
                ToSendDataBuffer[12] = debug_arr2[11];
                ToSendDataBuffer[13] = debug_arr2[12];
                ToSendDataBuffer[14] = debug_arr2[13];
                ToSendDataBuffer[15] = debug_arr2[14];
                ToSendDataBuffer[16] = debug_arr2[15];
#if 0
                for(fi = 0; fi < SW_NUM; fi++)
                {
                    ToSendDataBuffer[1+fi] = sw_now_fix[fi];
                }
#endif

                if(!HIDTxHandleBusy(USBInHandle))
                {
                    USBInHandle = HIDTxPacket(HID_EP,(BYTE*)&ToSendDataBuffer[0],64);
                }
                break;
#endif
        }
        //Re-arm the OUT endpoint, so we can receive the next OUT data packet
        //that the host may try to send us.
        USBOutHandle = HIDRxPacket(HID_EP, (BYTE*)&ReceivedDataBuffer, 64);
    }


//    return;
}//end USB_Comm()


