#include "Main_sub.h"


// *****************************************************************************
// *****************************************************************************
// Section: Software Delay
// *****************************************************************************
// *****************************************************************************
void Soft_Delay(DWORD delayValue)
{
    DWORD tmp32=0;

    TMR4 = 0;
    TMR5 = 0;
    while(1)
    {
        tmp32 = TMR5;                   // Timer32 ���16bit
        tmp32 = (tmp32 << 16) | TMR4;   // Timer32 ����16bit
        if(tmp32 >= delayValue)
        {
            break;
        }
    }
}

void set_LED(unsigned char no, unsigned char onoff){
	if(onoff == 0 || onoff == 1)
	{
		switch(no)
		{
			case 1:		LED01 = onoff;	break;
			case 2:		LED02 = onoff;	break;
			case 3:		LED03 = onoff;	break;
			case 4:		LED04 = onoff;	break;
			case 5:		LED05 = onoff;	break;
			case 6:		LED06 = onoff;	break;
			case 7:		LED07 = onoff;	break;
			case 8:		LED08 = onoff;	break;
			case 9:		LED09 = onoff;	break;
			case 10:	LED10 = onoff;	break;
			default: break;
		}
	}	
}

void Switch_Input(void)
{
    BYTE fi;
    BYTE sw_now[SW_NUM];

    sw_now[SW_1_NO_IDX] 	= SW_1_NO;

    for( fi = 0; fi < SW_NUM; fi++ )
    {
        if(sw_now[fi] == R_ON)
        {
            sw_press_on_cnt[fi]++;
            if( sw_press_on_cnt[fi] >= SW_ON_DEBOUNCE_TIME)
            {
                sw_press_off_cnt[fi] = 0;
                sw_now_fix[fi] = N_ON;
                sw_press_on_cnt[fi] = SW_ON_DEBOUNCE_TIME;
            }
        }
        else
        {
            sw_press_off_cnt[fi]++;
            if(sw_press_off_cnt[fi] >= SW_OFF_DEBOUNCE_TIME)
            {
                sw_press_on_cnt[fi] = 0;
                sw_now_fix[fi] = N_OFF;
                sw_press_off_cnt[fi] = SW_OFF_DEBOUNCE_TIME;
            }
        }

        // SW Push���̏����ǉ�
        if( sw_now_fix_pre[fi] == N_OFF && sw_now_fix[fi] == N_ON )
        {	// �O��=OFF  ����=ON

        }
        else if( sw_now_fix_pre[fi] == N_ON && sw_now_fix[fi] == N_OFF )
        {	// �O��=ON  ����=OFF

        }

        // ����l�ۑ�
        sw_now_fix_pre[fi] = sw_now_fix[fi];
    }
}

